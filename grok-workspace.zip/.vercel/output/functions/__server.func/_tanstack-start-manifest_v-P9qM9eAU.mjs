//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-P9qM9eAU.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/categorias",
			"/contato",
			"/ofertas",
			"/produtos",
			"/sobre"
		],
		preloads: [
			"/assets/index-SVuuiq6Q.js",
			"/assets/utils-LYwLoR8n.js",
			"/assets/preload-helper-DHh3eWMm.js",
			"/assets/link-74Ta5sw6.js",
			"/assets/catalog-Dgf4DHYh.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-SVuuiq6Q.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DXNh14xz.js",
			"/assets/input-DE1wA1bz.js",
			"/assets/product-card-Dg35tVum.js"
		]
	},
	"/categorias": {
		filePath: "/workspace/src/routes/categorias.tsx",
		children: void 0,
		preloads: ["/assets/categorias-Dh20PmeM.js", "/assets/page-hero-CmTD2OvE.js"]
	},
	"/contato": {
		filePath: "/workspace/src/routes/contato.tsx",
		children: void 0,
		preloads: [
			"/assets/contato-Bh5pHJww.js",
			"/assets/page-hero-CmTD2OvE.js",
			"/assets/input-DE1wA1bz.js"
		]
	},
	"/ofertas": {
		filePath: "/workspace/src/routes/ofertas.tsx",
		children: void 0,
		preloads: [
			"/assets/ofertas-BZ1yWuRS.js",
			"/assets/page-hero-CmTD2OvE.js",
			"/assets/product-card-Dg35tVum.js"
		]
	},
	"/produtos": {
		filePath: "/workspace/src/routes/produtos.tsx",
		children: ["/produtos/$slug"],
		preloads: [
			"/assets/produtos-Dv9ozQM1.js",
			"/assets/page-hero-CmTD2OvE.js",
			"/assets/product-card-Dg35tVum.js"
		]
	},
	"/sobre": {
		filePath: "/workspace/src/routes/sobre.tsx",
		children: void 0,
		preloads: ["/assets/sobre-y5g3yjEA.js", "/assets/page-hero-CmTD2OvE.js"]
	},
	"/produtos/$slug": {
		filePath: "/workspace/src/routes/produtos.$slug.tsx",
		children: void 0,
		preloads: ["/assets/produtos._slug-BVP4dHb4.js"]
	}
} });
//#endregion
export { tsrStartManifest };
