import { c as getProduct, d as relatedProducts, n as discountPercent, r as formatPrice, s as getCategory, t as cn } from "./utils-CUPoiO0y.mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as buttonVariants, i as Button, n as Route, o as useCart, s as useStoreUi } from "./router-jeD5VIhU.mjs";
import { t as ProductCard } from "./product-card-g4yrGTAm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/produtos._slug-BhbbrnST.js
var import_jsx_runtime = require_jsx_runtime();
function ProductPage() {
	const { slug } = Route.useParams();
	const product = getProduct(slug);
	const add = useCart((s) => s.add);
	const setCartOpen = useStoreUi((s) => s.setCartOpen);
	if (!product) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-xl px-4 py-32 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Produto não encontrado"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "Este item não faz parte da coleção demonstrativa."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/produtos",
				className: cn(buttonVariants({ variant: "night" }), "mt-8 inline-flex"),
				children: "Voltar ao catálogo"
			})
		]
	});
	const category = getCategory(product.category);
	const discount = product.originalPrice ? discountPercent(product.price, product.originalPrice) : 0;
	const related = relatedProducts(product.id);
	function addToCart() {
		add(product.id);
		toast.success(`${product.name} adicionado ao carrinho`, {
			description: "Demonstração visual — nenhum pedido é enviado.",
			action: {
				label: "Ver carrinho",
				onClick: () => setCartOpen(true)
			}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "pt-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-4 py-10 sm:px-6 lg:grid-cols-2 lg:gap-16 lg:px-8 lg:py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-xl bg-soft",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: product.image,
					alt: product.name,
					className: "aspect-portrait w-full object-cover lg:aspect-photo",
					style: product.imagePosition ? { objectPosition: product.imagePosition } : void 0
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col justify-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] font-semibold uppercase tracking-[0.22em] text-muted",
						children: [category?.name, product.badge ? ` · ${product.badge}` : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl tracking-tight sm:text-5xl",
						children: product.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex items-baseline gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-3xl tabular-nums",
							children: formatPrice(product.price)
						}), product.originalPrice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted line-through tabular-nums",
							children: formatPrice(product.originalPrice)
						}), discount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-sale px-2.5 py-1 text-xs font-semibold text-on-sale",
							children: [
								"-",
								discount,
								"%"
							]
						}) : null] }) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-md text-base leading-relaxed text-muted",
						children: product.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-md text-sm leading-relaxed text-muted",
						children: product.details
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 space-y-2 text-sm",
						children: product.benefits.map((benefit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 size-1.5 shrink-0 rounded-full bg-primary" }), benefit]
						}, benefit))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "night",
							size: "lg",
							onClick: addToCart,
							children: "Adicionar ao carrinho"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/produtos",
							search: { categoria: product.category },
							className: cn(buttonVariants({
								variant: "outline",
								size: "lg"
							})),
							children: ["Mais em ", category?.name]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs text-muted",
						children: "Loja demonstrativa. O carrinho permanece neste navegador e nenhum pagamento é processado."
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl tracking-tight",
				children: "Você também pode gostar"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-4",
				children: related.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: item }, item.id))
			})]
		})]
	});
}
//#endregion
export { ProductPage as component };
