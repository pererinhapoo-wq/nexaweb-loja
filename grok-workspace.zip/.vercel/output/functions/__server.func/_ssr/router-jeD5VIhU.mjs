import { i as __toESM } from "../_runtime.mjs";
import { a as contact, c as getProduct, i as categories, p as searchProducts, r as formatPrice, t as cn } from "./utils-CUPoiO0y.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { J as require_react, S as useRouter, Y as require_jsx_runtime, _ as Outlet, b as createRootRoute, f as Scripts, g as createRouter, m as useRouterState, p as HeadContent, v as lazyRouteComponent, x as Link, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Search, d as Menu, f as Linkedin, i as TriangleAlert, l as Plus, n as X, o as ShoppingBag, p as Instagram, t as Youtube, u as Minus } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-jeD5VIhU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var useCart = create()(persist((set, get) => ({
	items: [],
	add: (id, qty = 1) => {
		const items = [...get().items];
		const existing = items.find((item) => item.id === id);
		if (existing) existing.qty += qty;
		else items.push({
			id,
			qty
		});
		set({ items });
	},
	remove: (id) => set({ items: get().items.filter((item) => item.id !== id) }),
	setQty: (id, qty) => {
		if (qty <= 0) {
			set({ items: get().items.filter((item) => item.id !== id) });
			return;
		}
		set({ items: get().items.map((item) => item.id === id ? {
			...item,
			qty
		} : item) });
	},
	clear: () => set({ items: [] }),
	count: () => get().items.reduce((sum, item) => sum + item.qty, 0),
	lines: () => get().items.map((item) => {
		const product = getProduct(item.id);
		return product ? {
			...item,
			product
		} : null;
	}).filter((line) => Boolean(line)),
	subtotal: () => get().lines().reduce((sum, line) => sum + line.product.price * line.qty, 0)
}), {
	name: "nexa-store-cart-demo",
	partialize: (state) => ({ items: state.items })
}));
var useStoreUi = create((set) => ({
	cartOpen: false,
	searchOpen: false,
	menuOpen: false,
	setCartOpen: (cartOpen) => set({
		cartOpen,
		menuOpen: false,
		searchOpen: false
	}),
	setSearchOpen: (searchOpen) => set({
		searchOpen,
		menuOpen: false,
		cartOpen: false
	}),
	setMenuOpen: (menuOpen) => set({
		menuOpen,
		searchOpen: false,
		cartOpen: false
	})
}));
var nav = [
	{
		to: "/",
		label: "Início"
	},
	{
		to: "/produtos",
		label: "Produtos"
	},
	{
		to: "/categorias",
		label: "Categorias"
	},
	{
		to: "/ofertas",
		label: "Ofertas"
	},
	{
		to: "/sobre",
		label: "Sobre"
	},
	{
		to: "/contato",
		label: "Contato"
	}
];
function Logo({ inverted = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: cn("flex flex-col leading-none", inverted ? "text-on-night" : "text-ink"),
		"aria-label": "Nexa Store — início",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-[1.35rem] tracking-tight",
			children: "Nexa"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-0.5 text-[10px] font-semibold uppercase tracking-[0.38em] opacity-70",
			children: "Store"
		})]
	});
}
function Header() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const isHome = pathname === "/";
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const count = useCart((s) => s.items.reduce((sum, item) => sum + item.qty, 0));
	const [ready, setReady] = (0, import_react.useState)(false);
	const setCartOpen = useStoreUi((s) => s.setCartOpen);
	const setSearchOpen = useStoreUi((s) => s.setSearchOpen);
	const setMenuOpen = useStoreUi((s) => s.setMenuOpen);
	(0, import_react.useEffect)(() => {
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	const solid = !isHome || scrolled;
	const inverted = isHome && !scrolled;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: cn("fixed inset-x-0 top-0 z-40 transition-[background-color,box-shadow,color,backdrop-filter] duration-300 ease-out", solid ? "bg-canvas/90 text-ink shadow-[0_1px_0_rgba(26,24,21,0.08)] backdrop-blur-md" : "bg-transparent text-on-night"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:h-20 sm:px-6 lg:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { inverted }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-7 lg:flex",
					"aria-label": "Principal",
					children: nav.map((item) => {
						const active = item.to === "/" ? pathname === "/" : pathname === item.to || pathname.startsWith(`${item.to}/`);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							className: cn("relative text-[13px] font-medium uppercase tracking-[0.16em] transition-opacity duration-150 after:absolute after:-bottom-1 after:left-0 after:h-px after:w-full after:origin-left after:scale-x-0 after:bg-current after:transition-transform after:duration-200 hover:opacity-100 hover:after:scale-x-100", active ? "opacity-100 after:scale-x-100" : "opacity-70"),
							children: item.label
						}, item.to);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Pesquisar",
							onClick: () => setSearchOpen(true),
							className: "relative flex size-11 items-center justify-center rounded-lg transition-colors duration-150 hover:bg-current/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								className: "size-5",
								strokeWidth: 1.6
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-label": "Abrir carrinho",
							onClick: () => setCartOpen(true),
							className: "relative flex size-11 items-center justify-center rounded-lg transition-colors duration-150 hover:bg-current/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, {
								className: "size-5",
								strokeWidth: 1.6
							}), ready && count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute right-1.5 top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-sale px-1 text-[10px] font-semibold tabular-nums text-on-sale",
								children: count
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Abrir menu",
							onClick: () => setMenuOpen(true),
							className: "relative flex size-11 items-center justify-center rounded-lg transition-colors duration-150 hover:bg-current/10 lg:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
								className: "size-5",
								strokeWidth: 1.6
							})
						})
					]
				})
			]
		})
	});
}
var quick = [
	{
		to: "/",
		label: "Início"
	},
	{
		to: "/produtos",
		label: "Produtos"
	},
	{
		to: "/ofertas",
		label: "Ofertas"
	},
	{
		to: "/sobre",
		label: "Sobre"
	},
	{
		to: "/contato",
		label: "Contato"
	}
];
function Footer() {
	function fakeSocial(name) {
		toast("Perfil fictício", { description: `${name} existe apenas neste modelo demonstrativo da NexaWeb.` });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "bg-night text-on-night",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-12 lg:px-8 lg:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { inverted: true }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-xs text-sm leading-relaxed text-on-night/70",
					children: "Uma loja editorial de produtos selecionados. Modelo demonstrativo criado para apresentar uma experiência de compra contemporânea."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 sm:grid-cols-3 lg:col-span-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold uppercase tracking-[0.22em] text-on-night/50",
						children: "Links rápidos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-2.5",
						children: quick.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							className: "text-sm text-on-night/80 transition-colors hover:text-on-night",
							children: item.label
						}) }, item.to))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold uppercase tracking-[0.22em] text-on-night/50",
						children: "Categorias"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-2.5",
						children: categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/produtos",
							search: { categoria: category.id },
							className: "text-sm text-on-night/80 transition-colors hover:text-on-night",
							children: category.name
						}) }, category.id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold uppercase tracking-[0.22em] text-on-night/50",
							children: "Contato"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-2.5 text-sm text-on-night/80",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: contact.email }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: contact.phone }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: contact.hours }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "max-w-64 leading-relaxed",
									children: contact.address
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 flex gap-2",
							children: [
								["Instagram", Instagram],
								["LinkedIn", Linkedin],
								["YouTube", Youtube]
							].map(([name, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": name,
								onClick: () => fakeSocial(name),
								className: "flex size-11 items-center justify-center rounded-lg bg-on-night/8 text-on-night transition-colors hover:bg-on-night/14",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4",
									strokeWidth: 1.6
								})
							}, name))
						})
					] })
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-on-night/10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-7xl flex-col gap-2 px-4 py-6 text-xs text-on-night/50 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Modelo demonstrativo desenvolvido pela NexaWeb." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" Nexa Store. Conteúdo fictício — sem marcas reais."
				] })]
			})
		})]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium tracking-wide transition-[background-color,color,transform,box-shadow,border-color,opacity] duration-150 ease-out active:not-disabled:scale-[0.96] disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary", {
	variants: {
		variant: {
			primary: "bg-primary text-on-primary hover:bg-primary/90",
			night: "bg-night text-on-night hover:bg-ink",
			outline: "bg-transparent text-ink shadow-[0_0_0_1px_rgba(26,24,21,0.18)] hover:bg-ink hover:text-on-night",
			ghost: "bg-transparent text-ink hover:bg-soft",
			light: "bg-surface text-ink hover:bg-canvas",
			sale: "bg-sale text-on-sale hover:bg-sale/90"
		},
		size: {
			sm: "h-10 px-4 text-sm rounded-md",
			md: "h-11 px-5 text-sm rounded-lg",
			lg: "h-12 px-6 text-[15px] rounded-lg",
			icon: "size-11 rounded-lg"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = (0, import_react.forwardRef)(({ className, variant, size, type = "button", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	ref,
	type,
	className: cn(buttonVariants({
		variant,
		size
	}), className),
	...props
}));
Button.displayName = "Button";
function CartDrawer() {
	const open = useStoreUi((s) => s.cartOpen);
	const setOpen = useStoreUi((s) => s.setCartOpen);
	const items = useCart((s) => s.items);
	const setQty = useCart((s) => s.setQty);
	const remove = useCart((s) => s.remove);
	const clear = useCart((s) => s.clear);
	const lines = items.map((item) => {
		const product = getProduct(item.id);
		return product ? {
			...item,
			product
		} : null;
	}).filter((line) => Boolean(line));
	const subtotal = lines.reduce((sum, line) => sum + line.product.price * line.qty, 0);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		document.body.style.overflow = "hidden";
		window.addEventListener("keydown", onKey);
		return () => {
			document.body.style.overflow = "";
			window.removeEventListener("keydown", onKey);
		};
	}, [open, setOpen]);
	function checkout() {
		toast("Checkout de demonstração", { description: "Nenhum pagamento é processado neste modelo. O carrinho existe só no navegador." });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("fixed inset-0 z-50", open ? "pointer-events-auto" : "pointer-events-none"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Fechar carrinho",
			onClick: () => setOpen(false),
			className: cn("absolute inset-0 bg-night/40 transition-opacity duration-300 ease-out", open ? "opacity-100" : "opacity-0")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "cart-title",
			className: cn("absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-canvas text-ink shadow-lift transition-transform duration-300 ease-out", open ? "translate-x-0" : "translate-x-full"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-line px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.2em] text-muted",
						children: "Demonstração"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "cart-title",
						className: "font-display text-2xl",
						children: "Carrinho"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Fechar",
						onClick: () => setOpen(false),
						className: "flex size-11 items-center justify-center rounded-lg hover:bg-soft",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 overflow-y-auto px-5 py-5",
					children: lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-full flex-col items-center justify-center text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl",
								children: "Seu carrinho está vazio"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-xs text-sm text-muted",
								children: "Explore a coleção e adicione peças. Nada é cobrado neste modelo."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "mt-6",
								onClick: () => setOpen(false),
								variant: "night",
								children: "Continuar olhando"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-5",
						children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/produtos/$slug",
								params: { slug: line.product.id },
								onClick: () => setOpen(false),
								className: "size-24 shrink-0 overflow-hidden rounded-lg bg-soft",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: line.product.image,
									alt: "",
									className: "size-full object-cover"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/produtos/$slug",
											params: { slug: line.product.id },
											onClick: () => setOpen(false),
											className: "font-display text-lg leading-snug",
											children: line.product.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "text-xs text-muted underline-offset-2 hover:text-ink hover:underline",
											onClick: () => remove(line.id),
											children: "Remover"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm tabular-nums",
										children: formatPrice(line.product.price)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 inline-flex items-center rounded-md bg-surface shadow-card",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-label": "Diminuir quantidade",
												className: "flex size-10 items-center justify-center",
												onClick: () => setQty(line.id, line.qty - 1),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "w-6 text-center text-sm tabular-nums",
												children: line.qty
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-label": "Aumentar quantidade",
												className: "flex size-10 items-center justify-center",
												onClick: () => setQty(line.id, line.qty + 1),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
											})
										]
									})
								]
							})]
						}, line.id))
					})
				}),
				items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-line px-5 py-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Subtotal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg font-medium tabular-nums",
								children: formatPrice(subtotal)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted",
							children: "Frete e impostos não se aplicam — esta loja não processa pedidos reais."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-4 w-full",
							size: "lg",
							variant: "night",
							onClick: checkout,
							children: "Finalizar (demonstração)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-3 w-full text-center text-xs text-muted underline-offset-2 hover:text-ink hover:underline",
							onClick: clear,
							children: "Esvaziar carrinho"
						})
					]
				}) : null
			]
		})]
	});
}
function SearchOverlay() {
	const open = useStoreUi((s) => s.searchOpen);
	const setOpen = useStoreUi((s) => s.setSearchOpen);
	const [query, setQuery] = (0, import_react.useState)("");
	const inputRef = (0, import_react.useRef)(null);
	const results = (0, import_react.useMemo)(() => searchProducts(query), [query]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setQuery("");
		const id = window.setTimeout(() => inputRef.current?.focus(), 40);
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		document.body.style.overflow = "hidden";
		window.addEventListener("keydown", onKey);
		return () => {
			window.clearTimeout(id);
			document.body.style.overflow = "";
			window.removeEventListener("keydown", onKey);
		};
	}, [open, setOpen]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("fixed inset-0 z-50", open ? "pointer-events-auto" : "pointer-events-none"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Fechar pesquisa",
			onClick: () => setOpen(false),
			className: cn("absolute inset-0 bg-night/45 transition-opacity duration-300 ease-out", open ? "opacity-100" : "opacity-0")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "search-title",
			className: cn("absolute inset-x-0 top-0 mx-auto max-w-2xl bg-canvas px-4 pb-6 pt-5 shadow-lift transition-[opacity,transform] duration-300 ease-out sm:mt-16 sm:rounded-xl sm:px-6", open ? "translate-y-0 opacity-100" : "-translate-y-4 opacity-0"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "search-title",
						className: "font-display text-2xl",
						children: "Pesquisar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Fechar",
						onClick: () => setOpen(false),
						className: "flex size-11 items-center justify-center rounded-lg hover:bg-soft",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 flex h-12 items-center gap-3 rounded-lg bg-surface px-4 shadow-[0_0_0_1px_rgba(26,24,21,0.12)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: inputRef,
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "Nome, categoria ou descrição",
						className: "h-full w-full bg-transparent text-base text-ink outline-none placeholder:text-muted"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 max-h-[55vh] overflow-y-auto",
					children: query.trim() && results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "py-8 text-center text-sm text-muted",
						children: [
							"Nenhum produto encontrado para “",
							query,
							"”."
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: results.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/produtos/$slug",
						params: { slug: product.id },
						onClick: () => setOpen(false),
						className: "flex items-center gap-4 rounded-lg px-2 py-3 transition-colors hover:bg-soft",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: product.image,
							alt: "",
							className: "size-16 rounded-md object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-medium",
								children: product.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm tabular-nums text-muted",
								children: formatPrice(product.price)
							})]
						})]
					}) }, product.id)) })
				})
			]
		})]
	});
}
function MobileNav() {
	const open = useStoreUi((s) => s.menuOpen);
	const setOpen = useStoreUi((s) => s.setMenuOpen);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname, setOpen]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		document.body.style.overflow = "hidden";
		window.addEventListener("keydown", onKey);
		return () => {
			document.body.style.overflow = "";
			window.removeEventListener("keydown", onKey);
		};
	}, [open, setOpen]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("fixed inset-0 z-50 lg:hidden", open ? "pointer-events-auto" : "pointer-events-none"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Fechar menu",
			onClick: () => setOpen(false),
			className: cn("absolute inset-0 bg-night/40 transition-opacity duration-300", open ? "opacity-100" : "opacity-0")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: cn("absolute left-0 top-0 flex h-full w-80 max-w-full flex-col bg-canvas px-6 py-5 shadow-lift transition-transform duration-300 ease-out", open ? "translate-x-0" : "-translate-x-full"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl",
					children: "Menu"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Fechar",
					onClick: () => setOpen(false),
					className: "flex size-11 items-center justify-center rounded-lg hover:bg-soft",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mt-8 flex flex-col gap-1",
				children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: item.to,
					className: "rounded-lg px-3 py-3 text-lg font-medium hover:bg-soft",
					children: item.label
				}, item.to))
			})]
		})]
	});
}
function StoreShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-canvas text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartDrawer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchOverlay, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileNav, {})
		]
	});
}
var styles_default = "/assets/styles-0ZikYvth.css";
var APP_NAME = "Nexa Store";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Nexa Store — loja virtual demonstrativa da NexaWeb. Produtos, preços e avaliações fictícios."
			},
			{
				name: "theme-color",
				content: "#F3EFE8"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: Root
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "bottom-center",
				toastOptions: { className: "font-sans" }
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$6 = () => import("./routes-CI2soXd4.mjs");
var Route$6 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./categorias-KjVBZdSJ.mjs");
var Route$5 = createFileRoute("/categorias")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./contato-B2ed-OxU.mjs");
var Route$4 = createFileRoute("/contato")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./ofertas-tR4Qtu3a.mjs");
var Route$3 = createFileRoute("/ofertas")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./produtos-BBJBUqpO.mjs");
var categoryIds = new Set(categories.map((category) => category.id));
var Route$2 = createFileRoute("/produtos")({
	validateSearch: (search) => {
		const value = search.categoria;
		if (typeof value === "string" && categoryIds.has(value)) return { categoria: value };
		return {};
	},
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./sobre-Dnih32uQ.mjs");
var Route$1 = createFileRoute("/sobre")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./produtos._slug-BhbbrnST.mjs");
var Route = createFileRoute("/produtos/$slug")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$6.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$7
});
var CategoriasRoute = Route$5.update({
	id: "/categorias",
	path: "/categorias",
	getParentRoute: () => Route$7
});
var ContatoRoute = Route$4.update({
	id: "/contato",
	path: "/contato",
	getParentRoute: () => Route$7
});
var OfertasRoute = Route$3.update({
	id: "/ofertas",
	path: "/ofertas",
	getParentRoute: () => Route$7
});
var ProdutosRoute = Route$2.update({
	id: "/produtos",
	path: "/produtos",
	getParentRoute: () => Route$7
});
var SobreRoute = Route$1.update({
	id: "/sobre",
	path: "/sobre",
	getParentRoute: () => Route$7
});
var ProdutosRouteChildren = { ProdutosSlugRoute: Route.update({
	id: "/$slug",
	path: "/$slug",
	getParentRoute: () => ProdutosRoute
}) };
var rootRouteChildren = {
	IndexRoute,
	CategoriasRoute,
	ContatoRoute,
	OfertasRoute,
	ProdutosRoute: ProdutosRoute._addFileChildren(ProdutosRouteChildren),
	SobreRoute
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { buttonVariants as a, Button as i, Route as n, useCart as o, Route$2 as r, useStoreUi as s, router_exports as t };
