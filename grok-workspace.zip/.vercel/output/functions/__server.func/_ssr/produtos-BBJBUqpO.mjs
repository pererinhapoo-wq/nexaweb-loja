import { i as categories, t as cn, u as products } from "./utils-CUPoiO0y.mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PageHero } from "./page-hero-DhMqdK2n.mjs";
import { r as Route$2 } from "./router-jeD5VIhU.mjs";
import { t as ProductCard } from "./product-card-g4yrGTAm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/produtos-BBJBUqpO.js
var import_jsx_runtime = require_jsx_runtime();
function ProdutosPage() {
	const { categoria } = Route$2.useSearch();
	const visible = categoria ? products.filter((product) => product.category === categoria) : products;
	const activeName = categories.find((category) => category.id === categoria)?.name;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		kicker: "Catálogo",
		title: activeName ? activeName : "Todos os produtos",
		children: activeName ? `Um recorte da coleção em ${activeName.toLowerCase()}. Filtro apenas visual — o estoque é fictício.` : "Oito peças selecionadas para este modelo. Filtre por categoria ou abra qualquer produto."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 sm:mx-0 sm:flex-wrap sm:overflow-visible sm:px-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
				to: "/produtos",
				active: !categoria,
				children: "Tudo"
			}), categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
				to: "/produtos",
				search: { categoria: category.id },
				active: categoria === category.id,
				children: category.name
			}, category.id))]
		}), visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-20 text-center text-muted",
			children: "Nenhum produto nesta categoria."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-4",
			children: visible.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product }, product.id))
		})]
	})] });
}
function FilterChip({ children, active, to, search }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		search,
		className: cn("inline-flex h-11 shrink-0 items-center rounded-full px-4 text-sm font-medium transition-colors duration-150", active ? "bg-night text-on-night" : "bg-surface text-ink hover:bg-soft"),
		children
	});
}
//#endregion
export { ProdutosPage as component };
