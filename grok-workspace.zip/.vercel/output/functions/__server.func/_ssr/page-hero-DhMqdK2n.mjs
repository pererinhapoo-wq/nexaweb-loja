import { t as cn } from "./utils-CUPoiO0y.mjs";
import { Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/page-hero-DhMqdK2n.js
var import_jsx_runtime = require_jsx_runtime();
function PageHero({ kicker, title, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("bg-canvas pt-28 pb-10 sm:pt-32 sm:pb-14", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
			children: [
				kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-semibold uppercase tracking-[0.22em] text-muted",
					children: kicker
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 max-w-3xl font-display text-4xl leading-[1.1] tracking-tight sm:text-5xl lg:text-6xl",
					children: title
				}),
				children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 max-w-xl text-base leading-relaxed text-muted",
					children
				}) : null
			]
		})
	});
}
//#endregion
export { PageHero as t };
