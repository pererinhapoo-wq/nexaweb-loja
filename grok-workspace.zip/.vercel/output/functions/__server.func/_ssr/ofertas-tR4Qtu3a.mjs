import { l as offerProducts } from "./utils-CUPoiO0y.mjs";
import { Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PageHero } from "./page-hero-DhMqdK2n.mjs";
import { t as ProductCard } from "./product-card-g4yrGTAm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ofertas-tR4Qtu3a.js
var import_jsx_runtime = require_jsx_runtime();
function OfertasPage() {
	const offers = offerProducts();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		kicker: "Promoções",
		title: "Ofertas que valem a pena",
		children: "Preços riscados e porcentagens de desconto fazem parte deste cenário demonstrativo. Nada é cobrado ao adicionar ao carrinho."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-3",
			children: offers.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product }, product.id))
		})
	})] });
}
//#endregion
export { OfertasPage as component };
