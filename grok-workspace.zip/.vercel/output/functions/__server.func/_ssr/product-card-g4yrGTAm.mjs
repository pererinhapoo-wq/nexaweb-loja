import { n as discountPercent, r as formatPrice, t as cn } from "./utils-CUPoiO0y.mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useCart, s as useStoreUi } from "./router-jeD5VIhU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-card-g4yrGTAm.js
var import_jsx_runtime = require_jsx_runtime();
function ProductCard({ product, className }) {
	const add = useCart((s) => s.add);
	const setCartOpen = useStoreUi((s) => s.setCartOpen);
	const discount = product.originalPrice ? discountPercent(product.price, product.originalPrice) : 0;
	function addToCart() {
		add(product.id);
		toast.success(`${product.name} adicionado ao carrinho`, {
			description: "Demonstração visual — nenhum pedido é enviado.",
			action: {
				label: "Ver carrinho",
				onClick: () => setCartOpen(true)
			}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("group flex flex-col", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/produtos/$slug",
			params: { slug: product.id },
			className: "relative block overflow-hidden rounded-xl bg-soft",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "aspect-portrait overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: product.image,
						alt: product.name,
						className: "size-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]",
						style: product.imagePosition ? { objectPosition: product.imagePosition } : void 0
					})
				}),
				product.badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("absolute left-3 top-3 rounded-full px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.14em]", product.badge === "Oferta" ? "bg-sale text-on-sale" : "bg-primary text-on-primary"),
					children: product.badge
				}) : null,
				discount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "absolute right-3 top-3 rounded-full bg-night/80 px-2.5 py-1 text-[11px] font-semibold tabular-nums text-on-night",
					children: [
						"-",
						discount,
						"%"
					]
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/produtos/$slug",
					params: { slug: product.id },
					className: "font-display text-xl leading-snug text-ink transition-opacity duration-150 hover:opacity-70",
					children: product.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-baseline gap-2 tabular-nums",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[15px] font-medium text-ink",
						children: formatPrice(product.price)
					}), product.originalPrice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted line-through",
						children: formatPrice(product.originalPrice)
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: addToCart,
					className: "mt-4 h-11 rounded-lg bg-night text-sm font-medium text-on-night transition-[background-color,transform] duration-150 ease-out hover:bg-ink active:scale-[0.96]",
					children: "Adicionar ao carrinho"
				})
			]
		})]
	});
}
//#endregion
export { ProductCard as t };
