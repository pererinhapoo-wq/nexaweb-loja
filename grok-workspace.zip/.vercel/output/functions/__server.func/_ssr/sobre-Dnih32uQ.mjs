import { t as cn } from "./utils-CUPoiO0y.mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PageHero } from "./page-hero-DhMqdK2n.mjs";
import { a as buttonVariants } from "./router-jeD5VIhU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sobre-Dnih32uQ.js
var import_jsx_runtime = require_jsx_runtime();
function SobrePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		kicker: "A loja",
		title: "Uma vitrine, não um estoque real",
		children: "A Nexa Store é um modelo demonstrativo desenvolvido pela NexaWeb para apresentar como uma loja virtual contemporânea pode se comportar — no ritmo, no visual e no detalhe."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-4 pb-20 sm:px-6 lg:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/hero.jpg",
					alt: "Interior da coleção Nexa Store",
					className: "aspect-wide w-full object-cover"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 space-y-6 text-base leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nenhuma marca, pessoa ou empresa real aparece nestas páginas. Produtos, preços, avaliações, endereços e canais de atendimento foram inventados para o projeto." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "O carrinho funciona no navegador, como uma simulação. Não há banco de dados, login ou pagamento. O objetivo é deixar um cliente ver, sentir e navegar uma loja pronta — antes de construir a operação de verdade." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Se este modelo fosse um projeto publicado, o mesmo desenho receberia catálogo real, estoque, frete e um checkout seguro. Aqui, o que importa é a experiência." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/produtos",
				className: cn(buttonVariants({
					variant: "night",
					size: "lg"
				}), "mt-10 inline-flex"),
				children: "Ver a coleção"
			})
		]
	})] });
}
//#endregion
export { SobrePage as component };
