import { i as __toESM } from "../_runtime.mjs";
import { a as contact } from "./utils-CUPoiO0y.mjs";
import { J as require_react, Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PageHero } from "./page-hero-DhMqdK2n.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Button } from "./router-jeD5VIhU.mjs";
import { t as Input } from "./input-YD9d01Gy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contato-B2ed-OxU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ContatoPage() {
	const [sent, setSent] = (0, import_react.useState)(false);
	function onSubmit(event) {
		event.preventDefault();
		setSent(true);
		toast("Mensagem de demonstração", { description: "Nenhum dado foi enviado. Este é um modelo da NexaWeb." });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		kicker: "Atendimento",
		title: "Contato",
		children: "Horário, telefone e endereço abaixo são fictícios. Use o formulário para ver o estado de envio — nada sai deste navegador."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto grid max-w-7xl gap-12 px-4 pb-20 sm:px-6 lg:grid-cols-2 lg:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "space-y-6 rounded-xl bg-surface p-8 shadow-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-[11px] font-semibold uppercase tracking-[0.2em] text-muted",
					children: "E-mail"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-2 text-lg",
					children: contact.email
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-[11px] font-semibold uppercase tracking-[0.2em] text-muted",
					children: "Telefone"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-2 text-lg",
					children: contact.phone
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-[11px] font-semibold uppercase tracking-[0.2em] text-muted",
					children: "Horário de atendimento"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-2 text-lg",
					children: contact.hours
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-[11px] font-semibold uppercase tracking-[0.2em] text-muted",
					children: "Endereço"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-2 text-lg leading-relaxed",
					children: contact.address
				})] })
			]
		}), sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col justify-center rounded-xl bg-surface px-8 py-12 shadow-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl",
				children: "Mensagem registrada na tela"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "Em produção, este envio seguiria para o time de atendimento. Neste modelo, nenhum servidor recebe o conteúdo."
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "space-y-4 rounded-xl bg-surface p-8 shadow-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Nome", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-1.5",
						name: "nome",
						required: true,
						placeholder: "Seu nome"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["E-mail", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-1.5",
						name: "email",
						type: "email",
						required: true,
						placeholder: "seu@email.com"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Mensagem", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						name: "mensagem",
						required: true,
						rows: 6,
						placeholder: "Como podemos ajudar?",
						className: "mt-1.5 w-full rounded-lg bg-canvas px-4 py-3 text-base text-ink shadow-[0_0_0_1px_rgba(26,24,21,0.12)] outline-none transition-[box-shadow] focus-visible:shadow-[0_0_0_2px_var(--color-primary)]"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "night",
					size: "lg",
					children: "Enviar mensagem"
				})
			]
		})]
	})] });
}
//#endregion
export { ContatoPage as component };
