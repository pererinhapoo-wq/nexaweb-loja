import { i as __toESM } from "../_runtime.mjs";
import { a as contact, f as reviews, i as categories, l as offerProducts, o as featuredProducts, r as formatPrice, t as cn, u as products } from "./utils-CUPoiO0y.mjs";
import { J as require_react, Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Sparkles, h as ArrowRight, m as Headphones, r as Truck, s as ShieldCheck } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as buttonVariants, i as Button, o as useCart, s as useStoreUi } from "./router-jeD5VIhU.mjs";
import { t as Input } from "./input-YD9d01Gy.mjs";
import { t as ProductCard } from "./product-card-g4yrGTAm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CI2soXd4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const featured = products.find((product) => product.featured) ?? products[0];
	const add = useCart((s) => s.add);
	const setCartOpen = useStoreUi((s) => s.setCartOpen);
	const [email, setEmail] = (0, import_react.useState)("");
	const [sent, setSent] = (0, import_react.useState)(false);
	function buyFeatured() {
		add(featured.id);
		toast.success(`${featured.name} adicionado ao carrinho`, {
			description: "Demonstração visual — nenhum pedido é enviado.",
			action: {
				label: "Ver carrinho",
				onClick: () => setCartOpen(true)
			}
		});
	}
	function onNewsletter(event) {
		event.preventDefault();
		setSent(true);
		toast("Cadastro de demonstração", { description: "Nenhum e-mail é armazenado neste modelo da NexaWeb." });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative min-h-svh overflow-hidden bg-night text-on-night",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/hero.jpg",
					alt: "Ambiente editorial da Nexa Store com poltrona, casaco e objetos selecionados",
					className: "absolute inset-0 size-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-r from-night/80 via-night/45 to-night/15" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto flex min-h-svh max-w-7xl flex-col justify-end px-4 pb-16 pt-28 sm:px-6 sm:pb-20 lg:justify-center lg:px-8 lg:pb-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rise text-[11px] font-semibold uppercase tracking-[0.28em] text-on-night/70",
							children: "Coleção demonstrativa"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "rise rise-d1 mt-4 max-w-2xl font-display text-4xl leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl",
							children: "Tudo o que você procura. Em um só lugar."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rise rise-d2 mt-5 max-w-md text-base leading-relaxed text-on-night/80 sm:text-lg",
							children: "Produtos selecionados, design moderno e uma experiência de compra criada para você."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rise rise-d3 mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/produtos",
								className: cn(buttonVariants({
									variant: "light",
									size: "lg"
								}), "min-w-40"),
								children: "Comprar agora"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/ofertas",
								className: cn(buttonVariants({
									variant: "outline",
									size: "lg"
								}), "min-w-40 border-on-night/30 text-on-night hover:bg-on-night hover:text-night"),
								children: "Ver ofertas"
							})]
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "categorias",
			className: "mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col justify-between gap-6 sm:flex-row sm:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-semibold uppercase tracking-[0.22em] text-muted",
					children: "Categorias"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl tracking-tight sm:text-5xl",
					children: "Um recorte de cada mundo"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/categorias",
					className: "inline-flex items-center gap-2 text-sm font-medium text-ink",
					children: ["Todas as categorias", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3 lg:gap-5",
				children: categories.map((category, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/produtos",
					search: { categoria: category.id },
					className: cn("group relative overflow-hidden rounded-xl bg-soft", index === 0 ? "col-span-2 aspect-wide lg:col-span-1 lg:aspect-photo" : "aspect-photo"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: category.image,
							alt: category.name,
							className: "absolute inset-0 size-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.05]"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-night/70 via-night/10 to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-x-0 bottom-0 p-4 sm:p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl text-on-night sm:text-3xl",
								children: category.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 hidden max-w-xs text-sm text-on-night/80 sm:block",
								children: category.blurb
							})]
						})
					]
				}, category.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "produtos",
			className: "bg-surface py-20 lg:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-between gap-6 sm:flex-row sm:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold uppercase tracking-[0.22em] text-muted",
						children: "Destaques"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl tracking-tight sm:text-5xl",
						children: "Peças que sustentam a coleção"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/produtos",
						className: "inline-flex items-center gap-2 text-sm font-medium",
						children: ["Ver todos", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-4",
					children: featuredProducts().map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product }, product.id))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "ofertas",
			className: "mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col justify-between gap-6 sm:flex-row sm:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-semibold uppercase tracking-[0.22em] text-sale",
					children: "Promoções"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl tracking-tight sm:text-5xl",
					children: "Ofertas que valem a pena"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/ofertas",
					className: cn(buttonVariants({ variant: "night" })),
					children: "Ver todas as ofertas"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-3",
				children: offerProducts().map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product }, product.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-night text-on-night",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative min-h-[360px] overflow-hidden lg:min-h-[640px]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: featured.image,
						alt: featured.name,
						className: "absolute inset-0 size-full object-cover"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-center px-4 py-16 sm:px-10 lg:px-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold uppercase tracking-[0.22em] text-on-night/55",
							children: "Produto em destaque"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-display text-4xl tracking-tight sm:text-5xl",
							children: featured.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-md text-base leading-relaxed text-on-night/75",
							children: featured.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 font-display text-3xl tabular-nums",
							children: formatPrice(featured.price)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-6 space-y-2 text-sm text-on-night/80",
							children: featured.benefits.map((benefit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 size-1.5 shrink-0 rounded-full bg-on-night/50" }), benefit]
							}, benefit))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "light",
								size: "lg",
								onClick: buyFeatured,
								children: "Comprar agora"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/produtos/$slug",
								params: { slug: featured.id },
								className: cn(buttonVariants({
									variant: "outline",
									size: "lg"
								}), "border-on-night/30 text-on-night hover:bg-on-night hover:text-night"),
								children: "Ver detalhes"
							})]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-semibold uppercase tracking-[0.22em] text-muted",
					children: "Experiência"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl tracking-tight sm:text-5xl",
					children: "Comprar sem atrito"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					{
						icon: ShieldCheck,
						title: "Compra segura",
						text: "Ambiente de demonstração com carrinho local. Em um projeto real, o checkout segue criptografado ponta a ponta."
					},
					{
						icon: Truck,
						title: "Entrega rápida",
						text: "Prazos e rastreio fariam parte da operação. Aqui, o fluxo existe para mostrar o ritmo da loja."
					},
					{
						icon: Sparkles,
						title: "Produtos selecionados",
						text: "Cada peça desta coleção foi inventada para o modelo — curadoria curta, visual consistente."
					},
					{
						icon: Headphones,
						title: "Suporte ao cliente",
						text: "Canal de atendimento visível, humano e fácil de achar. Horário e contato fictícios no rodapé."
					}
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-6 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
							className: "size-6 text-primary",
							strokeWidth: 1.5
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-5 font-display text-2xl",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted",
							children: item.text
						})
					]
				}, item.title))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-surface py-20 lg:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold uppercase tracking-[0.22em] text-muted",
						children: "Avaliações fictícias"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl tracking-tight sm:text-5xl",
						children: "O que dizem — neste modelo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-sm text-muted",
						children: "Depoimentos inventados para esta demonstração da NexaWeb. Nenhum cliente real foi citado."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-6 lg:grid-cols-3",
						children: reviews.map((review) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
							className: "flex flex-col rounded-xl bg-canvas p-7 shadow-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-2xl leading-snug tracking-tight",
								children: [
									"“",
									review.quote,
									"”"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
								className: "mt-8 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: review.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-muted",
									children: [
										review.city,
										" · ",
										review.product
									]
								})]
							})]
						}, review.id))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-xl bg-primary px-6 py-14 text-on-primary sm:px-12 lg:px-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-10 lg:grid-cols-[1.2fr_1fr] lg:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl tracking-tight sm:text-5xl",
						children: "Receba nossas novidades"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-md text-on-primary/80",
						children: "Cadastre seu e-mail para receber novidades e ofertas."
					})] }), sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg",
						children: "Obrigado. Neste modelo, nada foi enviado."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: onNewsletter,
						className: "flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "email",
							required: true,
							value: email,
							onChange: (event) => setEmail(event.target.value),
							placeholder: "seu@email.com",
							className: "bg-on-primary text-ink",
							"aria-label": "E-mail"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							variant: "night",
							size: "lg",
							className: "shrink-0",
							children: "Quero receber"
						})]
					})]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "contato",
			className: "mx-auto max-w-7xl px-4 pb-8 sm:px-6 lg:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-12 rounded-xl bg-surface px-6 py-14 shadow-card sm:px-10 lg:grid-cols-2 lg:px-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold uppercase tracking-[0.22em] text-muted",
						children: "Contato"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl tracking-tight",
						children: "Fale com a loja"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-md text-sm leading-relaxed text-muted",
						children: "Endereço, telefone e e-mail são fictícios. O formulário não envia dados para nenhum servidor."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-8 space-y-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "E-mail"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1",
								children: contact.email
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Telefone"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1",
								children: contact.phone
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Horário"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1",
								children: contact.hours
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Endereço"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1",
								children: contact.address
							})] })
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactForm, {})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "px-4 py-20 sm:px-6 lg:px-8 lg:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-4xl text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl tracking-tight sm:text-6xl",
					children: "Pronto para encontrar seu próximo produto?"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/produtos",
					className: cn(buttonVariants({
						variant: "night",
						size: "lg"
					}), "mt-8 inline-flex"),
					children: "Explorar produtos"
				})]
			})
		})
	] });
}
function ContactForm() {
	const [sent, setSent] = (0, import_react.useState)(false);
	function onSubmit(event) {
		event.preventDefault();
		setSent(true);
		toast("Mensagem de demonstração", { description: "Nenhum dado foi enviado. Este é um modelo da NexaWeb." });
	}
	if (sent) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col justify-center rounded-lg bg-canvas px-6 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl",
			children: "Recebemos o gesto."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-muted",
			children: "Em um projeto real, esta mensagem seguiria para o atendimento. Aqui, ela permanece só na tela."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm",
				children: ["Nome", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-1.5",
					name: "nome",
					required: true,
					placeholder: "Seu nome"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm",
				children: ["E-mail", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-1.5",
					name: "email",
					type: "email",
					required: true,
					placeholder: "seu@email.com"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm",
				children: ["Mensagem", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					name: "mensagem",
					required: true,
					rows: 5,
					placeholder: "Como podemos ajudar?",
					className: "mt-1.5 w-full rounded-lg bg-canvas px-4 py-3 text-base text-ink shadow-[0_0_0_1px_rgba(26,24,21,0.12)] outline-none transition-[box-shadow] focus-visible:shadow-[0_0_0_2px_var(--color-primary)]"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				variant: "night",
				size: "lg",
				children: "Enviar mensagem"
			})
		]
	});
}
//#endregion
export { Home as component };
