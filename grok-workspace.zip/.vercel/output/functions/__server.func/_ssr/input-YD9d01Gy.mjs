import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-CUPoiO0y.mjs";
import { J as require_react, Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/input-YD9d01Gy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Input = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	ref,
	className: cn("h-12 w-full rounded-lg bg-surface px-4 text-base text-ink shadow-[0_0_0_1px_rgba(26,24,21,0.12)] placeholder:text-muted/80 transition-[box-shadow] duration-150 ease-out", "focus-visible:outline-none focus-visible:shadow-[0_0_0_2px_var(--color-primary)]", className),
	...props
}));
Input.displayName = "Input";
//#endregion
export { Input as t };
