import { i as categories, u as products } from "./utils-CUPoiO0y.mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PageHero } from "./page-hero-DhMqdK2n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/categorias-KjVBZdSJ.js
var import_jsx_runtime = require_jsx_runtime();
function CategoriasPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		kicker: "Navegar",
		title: "Categorias",
		children: "Seis famílias de produtos, cada uma com fotografia própria. Todo o catálogo é fictício e existe para apresentar o modelo."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
			children: categories.map((category) => {
				const count = products.filter((product) => product.category === category.id).length;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/produtos",
					search: { categoria: category.id },
					className: "group overflow-hidden rounded-xl bg-soft",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative aspect-landscape overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: category.image,
								alt: category.name,
								className: "size-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-night/55 to-transparent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "absolute bottom-4 left-4 font-display text-3xl text-on-night",
								children: category.name
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-surface px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-muted",
							children: category.blurb
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs uppercase tracking-[0.16em] text-ink",
							children: [
								count,
								" ",
								count === 1 ? "peça" : "peças"
							]
						})]
					})]
				}, category.id);
			})
		})
	})] });
}
//#endregion
export { CategoriasPage as component };
