import { type FormEvent, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { contact } from "@/lib/catalog";
import { PageHero } from "@/components/sections/page-hero";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/contato")({
  component: ContatoPage,
});

function ContatoPage() {
  const [sent, setSent] = useState(false);

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    setSent(true);
    toast("Mensagem de demonstração", {
      description: "Nenhum dado foi enviado. Este é um modelo da NexaWeb.",
    });
  }

  return (
    <>
      <PageHero kicker="Atendimento" title="Contato">
        Horário, telefone e endereço abaixo são fictícios. Use o formulário para ver
        o estado de envio — nada sai deste navegador.
      </PageHero>
      <section className="mx-auto grid max-w-7xl gap-12 px-4 pb-20 sm:px-6 lg:grid-cols-2 lg:px-8">
        <dl className="space-y-6 rounded-xl bg-surface p-8 shadow-card">
          <div>
            <dt className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted">
              E-mail
            </dt>
            <dd className="mt-2 text-lg">{contact.email}</dd>
          </div>
          <div>
            <dt className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted">
              Telefone
            </dt>
            <dd className="mt-2 text-lg">{contact.phone}</dd>
          </div>
          <div>
            <dt className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted">
              Horário de atendimento
            </dt>
            <dd className="mt-2 text-lg">{contact.hours}</dd>
          </div>
          <div>
            <dt className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted">
              Endereço
            </dt>
            <dd className="mt-2 text-lg leading-relaxed">{contact.address}</dd>
          </div>
        </dl>

        {sent ? (
          <div className="flex flex-col justify-center rounded-xl bg-surface px-8 py-12 shadow-card">
            <p className="font-display text-3xl">Mensagem registrada na tela</p>
            <p className="mt-3 text-muted">
              Em produção, este envio seguiria para o time de atendimento. Neste
              modelo, nenhum servidor recebe o conteúdo.
            </p>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="space-y-4 rounded-xl bg-surface p-8 shadow-card">
            <label className="block text-sm">
              Nome
              <Input className="mt-1.5" name="nome" required placeholder="Seu nome" />
            </label>
            <label className="block text-sm">
              E-mail
              <Input
                className="mt-1.5"
                name="email"
                type="email"
                required
                placeholder="seu@email.com"
              />
            </label>
            <label className="block text-sm">
              Mensagem
              <textarea
                name="mensagem"
                required
                rows={6}
                placeholder="Como podemos ajudar?"
                className="mt-1.5 w-full rounded-lg bg-canvas px-4 py-3 text-base text-ink shadow-[0_0_0_1px_rgba(26,24,21,0.12)] outline-none transition-[box-shadow] focus-visible:shadow-[0_0_0_2px_var(--color-primary)]"
              />
            </label>
            <Button type="submit" variant="night" size="lg">
              Enviar mensagem
            </Button>
          </form>
        )}
      </section>
    </>
  );
}
