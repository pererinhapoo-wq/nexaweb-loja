import { Link, createFileRoute } from "@tanstack/react-router";
import {
  categories,
  products,
  type CategoryId,
} from "@/lib/catalog";
import { ProductCard } from "@/components/product-card";
import { PageHero } from "@/components/sections/page-hero";
import { cn } from "@/lib/utils";

const categoryIds = new Set(categories.map((category) => category.id));

type ProdutosSearch = {
  categoria?: CategoryId;
};

export const Route = createFileRoute("/produtos")({
  validateSearch: (search: Record<string, unknown>): ProdutosSearch => {
    const value = search.categoria;
    if (typeof value === "string" && categoryIds.has(value as CategoryId)) {
      return { categoria: value as CategoryId };
    }
    return {};
  },
  component: ProdutosPage,
});

function ProdutosPage() {
  const { categoria } = Route.useSearch();
  const visible = categoria
    ? products.filter((product) => product.category === categoria)
    : products;
  const activeName = categories.find((category) => category.id === categoria)?.name;

  return (
    <>
      <PageHero
        kicker="Catálogo"
        title={activeName ? activeName : "Todos os produtos"}
      >
        {activeName
          ? `Um recorte da coleção em ${activeName.toLowerCase()}. Filtro apenas visual — o estoque é fictício.`
          : "Oito peças selecionadas para este modelo. Filtre por categoria ou abra qualquer produto."}
      </PageHero>

      <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8">
        <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 sm:mx-0 sm:flex-wrap sm:overflow-visible sm:px-0">
          <FilterChip to="/produtos" active={!categoria}>
            Tudo
          </FilterChip>
          {categories.map((category) => (
            <FilterChip
              key={category.id}
              to="/produtos"
              search={{ categoria: category.id }}
              active={categoria === category.id}
            >
              {category.name}
            </FilterChip>
          ))}
        </div>

        {visible.length === 0 ? (
          <p className="py-20 text-center text-muted">Nenhum produto nesta categoria.</p>
        ) : (
          <div className="mt-8 grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
            {visible.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>
    </>
  );
}

function FilterChip({
  children,
  active,
  to,
  search,
}: {
  children: string;
  active: boolean;
  to: "/produtos";
  search?: ProdutosSearch;
}) {
  return (
    <Link
      to={to}
      search={search}
      className={cn(
        "inline-flex h-11 shrink-0 items-center rounded-full px-4 text-sm font-medium transition-colors duration-150",
        active ? "bg-night text-on-night" : "bg-surface text-ink hover:bg-soft",
      )}
    >
      {children}
    </Link>
  );
}
