import { Link, createFileRoute } from "@tanstack/react-router";
import { categories, products } from "@/lib/catalog";
import { PageHero } from "@/components/sections/page-hero";

export const Route = createFileRoute("/categorias")({
  component: CategoriasPage,
});

function CategoriasPage() {
  return (
    <>
      <PageHero kicker="Navegar" title="Categorias">
        Seis famílias de produtos, cada uma com fotografia própria. Todo o catálogo é
        fictício e existe para apresentar o modelo.
      </PageHero>
      <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((category) => {
            const count = products.filter((product) => product.category === category.id).length;
            return (
              <Link
                key={category.id}
                to="/produtos"
                search={{ categoria: category.id }}
                className="group overflow-hidden rounded-xl bg-soft"
              >
                <div className="relative aspect-landscape overflow-hidden">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="size-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
                  />
                  <div className="absolute inset-0 bg-linear-to-t from-night/55 to-transparent" />
                  <p className="absolute bottom-4 left-4 font-display text-3xl text-on-night">
                    {category.name}
                  </p>
                </div>
                <div className="bg-surface px-5 py-4">
                  <p className="text-sm leading-relaxed text-muted">{category.blurb}</p>
                  <p className="mt-2 text-xs uppercase tracking-[0.16em] text-ink">
                    {count} {count === 1 ? "peça" : "peças"}
                  </p>
                </div>
              </Link>
            );
          })}
        </div>
      </section>
    </>
  );
}
