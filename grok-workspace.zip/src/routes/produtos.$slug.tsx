import { Link, createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { getCategory, getProduct, relatedProducts } from "@/lib/catalog";
import { useCart, useStoreUi } from "@/lib/cart-store";
import { ProductCard } from "@/components/product-card";
import { Button, buttonVariants } from "@/components/ui/button";
import { cn, discountPercent, formatPrice } from "@/lib/utils";

export const Route = createFileRoute("/produtos/$slug")({
  component: ProductPage,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const product = getProduct(slug);
  const add = useCart((s) => s.add);
  const setCartOpen = useStoreUi((s) => s.setCartOpen);

  if (!product) {
    return (
      <section className="mx-auto max-w-xl px-4 py-32 text-center">
        <h1 className="font-display text-4xl">Produto não encontrado</h1>
        <p className="mt-3 text-muted">
          Este item não faz parte da coleção demonstrativa.
        </p>
        <Link
          to="/produtos"
          className={cn(buttonVariants({ variant: "night" }), "mt-8 inline-flex")}
        >
          Voltar ao catálogo
        </Link>
      </section>
    );
  }

  const item = product;
  const category = getCategory(item.category);
  const discount = item.originalPrice
    ? discountPercent(item.price, item.originalPrice)
    : 0;
  const related = relatedProducts(item.id);

  function addToCart() {
    add(item.id);
    toast.success(`${item.name} adicionado ao carrinho`, {
      description: "Demonstração visual — nenhum pedido é enviado.",
      action: { label: "Ver carrinho", onClick: () => setCartOpen(true) },
    });
  }

  return (
    <article className="pt-24">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-10 sm:px-6 lg:grid-cols-2 lg:gap-16 lg:px-8 lg:py-16">
        <div className="overflow-hidden rounded-xl bg-soft">
          <img
            src={item.image}
            alt={item.name}
            className="aspect-portrait w-full object-cover lg:aspect-photo"
            style={item.imagePosition ? { objectPosition: item.imagePosition } : undefined}
          />
        </div>
        <div className="flex flex-col justify-center">
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-muted">
            {category?.name}
            {item.badge ? ` · ${item.badge}` : ""}
          </p>
          <h1 className="mt-3 font-display text-4xl tracking-tight sm:text-5xl">
            {item.name}
          </h1>
          <div className="mt-5 flex items-baseline gap-3">
            <span className="font-display text-3xl tabular-nums">
              {formatPrice(item.price)}
            </span>
            {item.originalPrice ? (
              <>
                <span className="text-muted line-through tabular-nums">
                  {formatPrice(item.originalPrice)}
                </span>
                {discount > 0 ? (
                  <span className="rounded-full bg-sale px-2.5 py-1 text-xs font-semibold text-on-sale">
                    -{discount}%
                  </span>
                ) : null}
              </>
            ) : null}
          </div>
          <p className="mt-6 max-w-md text-base leading-relaxed text-muted">
            {item.description}
          </p>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-muted">
            {item.details}
          </p>
          <ul className="mt-6 space-y-2 text-sm">
            {item.benefits.map((benefit) => (
              <li key={benefit} className="flex gap-2">
                <span className="mt-2 size-1.5 shrink-0 rounded-full bg-primary" />
                {benefit}
              </li>
            ))}
          </ul>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button variant="night" size="lg" onClick={addToCart}>
              Adicionar ao carrinho
            </Button>
            <Link
              to="/produtos"
              search={{ categoria: item.category }}
              className={cn(buttonVariants({ variant: "outline", size: "lg" }))}
            >
              Mais em {category?.name}
            </Link>
          </div>
          <p className="mt-4 text-xs text-muted">
            Loja demonstrativa. O carrinho permanece neste navegador e nenhum pagamento
            é processado.
          </p>
        </div>
      </div>

      <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8">
        <h2 className="font-display text-3xl tracking-tight">Você também pode gostar</h2>
        <div className="mt-8 grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
          {related.map((item) => (
            <ProductCard key={item.id} product={item} />
          ))}
        </div>
      </section>
    </article>
  );
}
