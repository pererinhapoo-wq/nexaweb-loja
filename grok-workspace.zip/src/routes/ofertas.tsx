import { createFileRoute } from "@tanstack/react-router";
import { offerProducts } from "@/lib/catalog";
import { ProductCard } from "@/components/product-card";
import { PageHero } from "@/components/sections/page-hero";

export const Route = createFileRoute("/ofertas")({
  component: OfertasPage,
});

function OfertasPage() {
  const offers = offerProducts();

  return (
    <>
      <PageHero kicker="Promoções" title="Ofertas que valem a pena">
        Preços riscados e porcentagens de desconto fazem parte deste cenário
        demonstrativo. Nada é cobrado ao adicionar ao carrinho.
      </PageHero>
      <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8">
        <div className="grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
          {offers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>
    </>
  );
}
