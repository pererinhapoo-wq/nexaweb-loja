import { Link, createFileRoute } from "@tanstack/react-router";
import {
  ArrowRight,
  Headphones,
  ShieldCheck,
  Sparkles,
  Truck,
} from "lucide-react";
import { toast } from "sonner";
import { FormEvent, useState } from "react";
import {
  categories,
  contact,
  featuredProducts,
  offerProducts,
  products,
  reviews,
} from "@/lib/catalog";
import { useCart, useStoreUi } from "@/lib/cart-store";
import { ProductCard } from "@/components/product-card";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn, formatPrice } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const featured = products.find((product) => product.featured) ?? products[0];
  const add = useCart((s) => s.add);
  const setCartOpen = useStoreUi((s) => s.setCartOpen);
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  function buyFeatured() {
    add(featured.id);
    toast.success(`${featured.name} adicionado ao carrinho`, {
      description: "Demonstração visual — nenhum pedido é enviado.",
      action: { label: "Ver carrinho", onClick: () => setCartOpen(true) },
    });
  }

  function onNewsletter(event: FormEvent) {
    event.preventDefault();
    setSent(true);
    toast("Cadastro de demonstração", {
      description: "Nenhum e-mail é armazenado neste modelo da NexaWeb.",
    });
  }

  return (
    <>
      {/* Conteúdo demonstrativo e fictício. Modelo NexaWeb. Nenhuma marca real. */}
      <section className="relative min-h-svh overflow-hidden bg-night text-on-night">
        <img
          src="/images/hero.jpg"
          alt="Ambiente editorial da Nexa Store com poltrona, casaco e objetos selecionados"
          className="absolute inset-0 size-full object-cover"
        />
        <div className="absolute inset-0 bg-linear-to-r from-night/80 via-night/45 to-night/15" />
        <div className="relative mx-auto flex min-h-svh max-w-7xl flex-col justify-end px-4 pb-16 pt-28 sm:px-6 sm:pb-20 lg:justify-center lg:px-8 lg:pb-24">
          <p className="rise text-[11px] font-semibold uppercase tracking-[0.28em] text-on-night/70">
            Coleção demonstrativa
          </p>
          <h1 className="rise rise-d1 mt-4 max-w-2xl font-display text-4xl leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
            Tudo o que você procura. Em um só lugar.
          </h1>
          <p className="rise rise-d2 mt-5 max-w-md text-base leading-relaxed text-on-night/80 sm:text-lg">
            Produtos selecionados, design moderno e uma experiência de compra criada
            para você.
          </p>
          <div className="rise rise-d3 mt-8 flex flex-wrap gap-3">
            <Link
              to="/produtos"
              className={cn(buttonVariants({ variant: "light", size: "lg" }), "min-w-40")}
            >
              Comprar agora
            </Link>
            <Link
              to="/ofertas"
              className={cn(
                buttonVariants({ variant: "outline", size: "lg" }),
                "min-w-40 border-on-night/30 text-on-night hover:bg-on-night hover:text-night",
              )}
            >
              Ver ofertas
            </Link>
          </div>
        </div>
      </section>

      <section id="categorias" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-muted">
              Categorias
            </p>
            <h2 className="mt-3 font-display text-4xl tracking-tight sm:text-5xl">
              Um recorte de cada mundo
            </h2>
          </div>
          <Link
            to="/categorias"
            className="inline-flex items-center gap-2 text-sm font-medium text-ink"
          >
            Todas as categorias
            <ArrowRight className="size-4" />
          </Link>
        </div>
        <div className="mt-10 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3 lg:gap-5">
          {categories.map((category, index) => (
            <Link
              key={category.id}
              to="/produtos"
              search={{ categoria: category.id }}
              className={cn(
                "group relative overflow-hidden rounded-xl bg-soft",
                index === 0 ? "col-span-2 aspect-wide lg:col-span-1 lg:aspect-photo" : "aspect-photo",
              )}
            >
              <img
                src={category.image}
                alt={category.name}
                className="absolute inset-0 size-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.05]"
              />
              <div className="absolute inset-0 bg-linear-to-t from-night/70 via-night/10 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-4 sm:p-5">
                <p className="font-display text-2xl text-on-night sm:text-3xl">{category.name}</p>
                <p className="mt-1 hidden max-w-xs text-sm text-on-night/80 sm:block">
                  {category.blurb}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section id="produtos" className="bg-surface py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-muted">
                Destaques
              </p>
              <h2 className="mt-3 font-display text-4xl tracking-tight sm:text-5xl">
                Peças que sustentam a coleção
              </h2>
            </div>
            <Link
              to="/produtos"
              className="inline-flex items-center gap-2 text-sm font-medium"
            >
              Ver todos
              <ArrowRight className="size-4" />
            </Link>
          </div>
          <div className="mt-10 grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
            {featuredProducts().map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      <section id="ofertas" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-sale">
              Promoções
            </p>
            <h2 className="mt-3 font-display text-4xl tracking-tight sm:text-5xl">
              Ofertas que valem a pena
            </h2>
          </div>
          <Link
            to="/ofertas"
            className={cn(buttonVariants({ variant: "night" }))}
          >
            Ver todas as ofertas
          </Link>
        </div>
        <div className="mt-10 grid gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
          {offerProducts().map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <section className="bg-night text-on-night">
        <div className="mx-auto grid max-w-7xl lg:grid-cols-2">
          <div className="relative min-h-[360px] overflow-hidden lg:min-h-[640px]">
            <img
              src={featured.image}
              alt={featured.name}
              className="absolute inset-0 size-full object-cover"
            />
          </div>
          <div className="flex flex-col justify-center px-4 py-16 sm:px-10 lg:px-16">
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-on-night/55">
              Produto em destaque
            </p>
            <h2 className="mt-4 font-display text-4xl tracking-tight sm:text-5xl">
              {featured.name}
            </h2>
            <p className="mt-5 max-w-md text-base leading-relaxed text-on-night/75">
              {featured.description}
            </p>
            <p className="mt-6 font-display text-3xl tabular-nums">
              {formatPrice(featured.price)}
            </p>
            <ul className="mt-6 space-y-2 text-sm text-on-night/80">
              {featured.benefits.map((benefit) => (
                <li key={benefit} className="flex gap-2">
                  <span className="mt-2 size-1.5 shrink-0 rounded-full bg-on-night/50" />
                  {benefit}
                </li>
              ))}
            </ul>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button variant="light" size="lg" onClick={buyFeatured}>
                Comprar agora
              </Button>
              <Link
                to="/produtos/$slug"
                params={{ slug: featured.id }}
                className={cn(
                  buttonVariants({ variant: "outline", size: "lg" }),
                  "border-on-night/30 text-on-night hover:bg-on-night hover:text-night",
                )}
              >
                Ver detalhes
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="max-w-xl">
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-muted">
            Experiência
          </p>
          <h2 className="mt-3 font-display text-4xl tracking-tight sm:text-5xl">
            Comprar sem atrito
          </h2>
        </div>
        <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              icon: ShieldCheck,
              title: "Compra segura",
              text: "Ambiente de demonstração com carrinho local. Em um projeto real, o checkout segue criptografado ponta a ponta.",
            },
            {
              icon: Truck,
              title: "Entrega rápida",
              text: "Prazos e rastreio fariam parte da operação. Aqui, o fluxo existe para mostrar o ritmo da loja.",
            },
            {
              icon: Sparkles,
              title: "Produtos selecionados",
              text: "Cada peça desta coleção foi inventada para o modelo — curadoria curta, visual consistente.",
            },
            {
              icon: Headphones,
              title: "Suporte ao cliente",
              text: "Canal de atendimento visível, humano e fácil de achar. Horário e contato fictícios no rodapé.",
            },
          ].map((item) => (
            <article key={item.title} className="rounded-xl bg-surface p-6 shadow-card">
              <item.icon className="size-6 text-primary" strokeWidth={1.5} />
              <h3 className="mt-5 font-display text-2xl">{item.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted">{item.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="bg-surface py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-muted">
            Avaliações fictícias
          </p>
          <h2 className="mt-3 font-display text-4xl tracking-tight sm:text-5xl">
            O que dizem — neste modelo
          </h2>
          <p className="mt-4 max-w-xl text-sm text-muted">
            Depoimentos inventados para esta demonstração da NexaWeb. Nenhum cliente
            real foi citado.
          </p>
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {reviews.map((review) => (
              <blockquote
                key={review.id}
                className="flex flex-col rounded-xl bg-canvas p-7 shadow-card"
              >
                <p className="font-display text-2xl leading-snug tracking-tight">
                  “{review.quote}”
                </p>
                <footer className="mt-8 text-sm">
                  <p className="font-medium">{review.name}</p>
                  <p className="text-muted">
                    {review.city} · {review.product}
                  </p>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="overflow-hidden rounded-xl bg-primary px-6 py-14 text-on-primary sm:px-12 lg:px-16">
          <div className="grid gap-10 lg:grid-cols-[1.2fr_1fr] lg:items-center">
            <div>
              <h2 className="font-display text-4xl tracking-tight sm:text-5xl">
                Receba nossas novidades
              </h2>
              <p className="mt-4 max-w-md text-on-primary/80">
                Cadastre seu e-mail para receber novidades e ofertas.
              </p>
            </div>
            {sent ? (
              <p className="text-lg">Obrigado. Neste modelo, nada foi enviado.</p>
            ) : (
              <form onSubmit={onNewsletter} className="flex flex-col gap-3 sm:flex-row">
                <Input
                  type="email"
                  required
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="seu@email.com"
                  className="bg-on-primary text-ink"
                  aria-label="E-mail"
                />
                <Button type="submit" variant="night" size="lg" className="shrink-0">
                  Quero receber
                </Button>
              </form>
            )}
          </div>
        </div>
      </section>

      <section id="contato" className="mx-auto max-w-7xl px-4 pb-8 sm:px-6 lg:px-8">
        <div className="grid gap-12 rounded-xl bg-surface px-6 py-14 shadow-card sm:px-10 lg:grid-cols-2 lg:px-14">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-muted">
              Contato
            </p>
            <h2 className="mt-3 font-display text-4xl tracking-tight">Fale com a loja</h2>
            <p className="mt-4 max-w-md text-sm leading-relaxed text-muted">
              Endereço, telefone e e-mail são fictícios. O formulário não envia dados
              para nenhum servidor.
            </p>
            <dl className="mt-8 space-y-4 text-sm">
              <div>
                <dt className="text-muted">E-mail</dt>
                <dd className="mt-1">{contact.email}</dd>
              </div>
              <div>
                <dt className="text-muted">Telefone</dt>
                <dd className="mt-1">{contact.phone}</dd>
              </div>
              <div>
                <dt className="text-muted">Horário</dt>
                <dd className="mt-1">{contact.hours}</dd>
              </div>
              <div>
                <dt className="text-muted">Endereço</dt>
                <dd className="mt-1">{contact.address}</dd>
              </div>
            </dl>
          </div>
          <ContactForm />
        </div>
      </section>

      <section className="px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="mx-auto max-w-4xl text-center">
          <h2 className="font-display text-4xl tracking-tight sm:text-6xl">
            Pronto para encontrar seu próximo produto?
          </h2>
          <Link
            to="/produtos"
            className={cn(buttonVariants({ variant: "night", size: "lg" }), "mt-8 inline-flex")}
          >
            Explorar produtos
          </Link>
        </div>
      </section>
    </>
  );
}

function ContactForm() {
  const [sent, setSent] = useState(false);

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    setSent(true);
    toast("Mensagem de demonstração", {
      description: "Nenhum dado foi enviado. Este é um modelo da NexaWeb.",
    });
  }

  if (sent) {
    return (
      <div className="flex flex-col justify-center rounded-lg bg-canvas px-6 py-10">
        <p className="font-display text-3xl">Recebemos o gesto.</p>
        <p className="mt-3 text-sm text-muted">
          Em um projeto real, esta mensagem seguiria para o atendimento. Aqui, ela
          permanece só na tela.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <label className="block text-sm">
        Nome
        <Input className="mt-1.5" name="nome" required placeholder="Seu nome" />
      </label>
      <label className="block text-sm">
        E-mail
        <Input
          className="mt-1.5"
          name="email"
          type="email"
          required
          placeholder="seu@email.com"
        />
      </label>
      <label className="block text-sm">
        Mensagem
        <textarea
          name="mensagem"
          required
          rows={5}
          placeholder="Como podemos ajudar?"
          className="mt-1.5 w-full rounded-lg bg-canvas px-4 py-3 text-base text-ink shadow-[0_0_0_1px_rgba(26,24,21,0.12)] outline-none transition-[box-shadow] focus-visible:shadow-[0_0_0_2px_var(--color-primary)]"
        />
      </label>
      <Button type="submit" variant="night" size="lg">
        Enviar mensagem
      </Button>
    </form>
  );
}
