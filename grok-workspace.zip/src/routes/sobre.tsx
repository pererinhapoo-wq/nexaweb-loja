import { Link, createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/sections/page-hero";
import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/sobre")({
  component: SobrePage,
});

function SobrePage() {
  return (
    <>
      <PageHero kicker="A loja" title="Uma vitrine, não um estoque real">
        A Nexa Store é um modelo demonstrativo desenvolvido pela NexaWeb para
        apresentar como uma loja virtual contemporânea pode se comportar — no ritmo,
        no visual e no detalhe.
      </PageHero>
      <section className="mx-auto max-w-3xl px-4 pb-20 sm:px-6 lg:px-8">
        <div className="overflow-hidden rounded-xl">
          <img
            src="/images/hero.jpg"
            alt="Interior da coleção Nexa Store"
            className="aspect-wide w-full object-cover"
          />
        </div>
        <div className="mt-12 space-y-6 text-base leading-relaxed text-muted">
          <p>
            Nenhuma marca, pessoa ou empresa real aparece nestas páginas. Produtos,
            preços, avaliações, endereços e canais de atendimento foram inventados
            para o projeto.
          </p>
          <p>
            O carrinho funciona no navegador, como uma simulação. Não há banco de
            dados, login ou pagamento. O objetivo é deixar um cliente ver, sentir e
            navegar uma loja pronta — antes de construir a operação de verdade.
          </p>
          <p>
            Se este modelo fosse um projeto publicado, o mesmo desenho receberia
            catálogo real, estoque, frete e um checkout seguro. Aqui, o que importa
            é a experiência.
          </p>
        </div>
        <Link
          to="/produtos"
          className={cn(buttonVariants({ variant: "night", size: "lg" }), "mt-10 inline-flex")}
        >
          Ver a coleção
        </Link>
      </section>
    </>
  );
}
