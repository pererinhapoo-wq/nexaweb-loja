import { type InputHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => (
    <input
      ref={ref}
      className={cn(
        "h-12 w-full rounded-lg bg-surface px-4 text-base text-ink shadow-[0_0_0_1px_rgba(26,24,21,0.12)] placeholder:text-muted/80 transition-[box-shadow] duration-150 ease-out",
        "focus-visible:outline-none focus-visible:shadow-[0_0_0_2px_var(--color-primary)]",
        className,
      )}
      {...props}
    />
  ),
);

Input.displayName = "Input";
