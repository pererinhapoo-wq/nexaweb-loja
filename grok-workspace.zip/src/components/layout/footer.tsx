import { Link } from "@tanstack/react-router";
import { Instagram, Linkedin, Youtube } from "lucide-react";
import { toast } from "sonner";
import { categories, contact } from "@/lib/catalog";
import { Logo } from "@/components/layout/header";

const quick = [
  { to: "/", label: "Início" },
  { to: "/produtos", label: "Produtos" },
  { to: "/ofertas", label: "Ofertas" },
  { to: "/sobre", label: "Sobre" },
  { to: "/contato", label: "Contato" },
] as const;

export function Footer() {
  function fakeSocial(name: string) {
    toast("Perfil fictício", {
      description: `${name} existe apenas neste modelo demonstrativo da NexaWeb.`,
    });
  }

  return (
    <footer className="bg-night text-on-night">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-12 lg:px-8 lg:py-20">
        <div className="lg:col-span-4">
          <Logo inverted />
          <p className="mt-6 max-w-xs text-sm leading-relaxed text-on-night/70">
            Uma loja editorial de produtos selecionados. Modelo demonstrativo criado
            para apresentar uma experiência de compra contemporânea.
          </p>
        </div>

        <div className="grid gap-10 sm:grid-cols-3 lg:col-span-8">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-on-night/50">
              Links rápidos
            </p>
            <ul className="mt-4 space-y-2.5">
              {quick.map((item) => (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    className="text-sm text-on-night/80 transition-colors hover:text-on-night"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-on-night/50">
              Categorias
            </p>
            <ul className="mt-4 space-y-2.5">
              {categories.map((category) => (
                <li key={category.id}>
                  <Link
                    to="/produtos"
                    search={{ categoria: category.id }}
                    className="text-sm text-on-night/80 transition-colors hover:text-on-night"
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-on-night/50">
              Contato
            </p>
            <ul className="mt-4 space-y-2.5 text-sm text-on-night/80">
              <li>{contact.email}</li>
              <li>{contact.phone}</li>
              <li>{contact.hours}</li>
              <li className="max-w-64 leading-relaxed">{contact.address}</li>
            </ul>
            <div className="mt-5 flex gap-2">
              {(
                [
                  ["Instagram", Instagram],
                  ["LinkedIn", Linkedin],
                  ["YouTube", Youtube],
                ] as const
              ).map(([name, Icon]) => (
                <button
                  key={name}
                  type="button"
                  aria-label={name}
                  onClick={() => fakeSocial(name)}
                  className="flex size-11 items-center justify-center rounded-lg bg-on-night/8 text-on-night transition-colors hover:bg-on-night/14"
                >
                  <Icon className="size-4" strokeWidth={1.6} />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="border-t border-on-night/10">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-6 text-xs text-on-night/50 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
          <p>Modelo demonstrativo desenvolvido pela NexaWeb.</p>
          <p>© {new Date().getFullYear()} Nexa Store. Conteúdo fictício — sem marcas reais.</p>
        </div>
      </div>
    </footer>
  );
}
