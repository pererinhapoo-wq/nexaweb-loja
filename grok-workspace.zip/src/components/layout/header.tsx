import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, Search, ShoppingBag } from "lucide-react";
import { useCart, useStoreUi } from "@/lib/cart-store";
import { cn } from "@/lib/utils";

const nav = [
  { to: "/", label: "Início" },
  { to: "/produtos", label: "Produtos" },
  { to: "/categorias", label: "Categorias" },
  { to: "/ofertas", label: "Ofertas" },
  { to: "/sobre", label: "Sobre" },
  { to: "/contato", label: "Contato" },
] as const;

export function Logo({ inverted = false }: { inverted?: boolean }) {
  return (
    <Link
      to="/"
      className={cn(
        "flex flex-col leading-none",
        inverted ? "text-on-night" : "text-ink",
      )}
      aria-label="Nexa Store — início"
    >
      <span className="font-display text-[1.35rem] tracking-tight">Nexa</span>
      <span className="mt-0.5 text-[10px] font-semibold uppercase tracking-[0.38em] opacity-70">
        Store
      </span>
    </Link>
  );
}

export function Header() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isHome = pathname === "/";
  const [scrolled, setScrolled] = useState(false);
  const count = useCart((s) => s.items.reduce((sum, item) => sum + item.qty, 0));
  const [ready, setReady] = useState(false);
  const setCartOpen = useStoreUi((s) => s.setCartOpen);
  const setSearchOpen = useStoreUi((s) => s.setSearchOpen);
  const setMenuOpen = useStoreUi((s) => s.setMenuOpen);

  useEffect(() => {
    setReady(true);
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const solid = !isHome || scrolled;
  const inverted = isHome && !scrolled;

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-40 transition-[background-color,box-shadow,color,backdrop-filter] duration-300 ease-out",
        solid
          ? "bg-canvas/90 text-ink shadow-[0_1px_0_rgba(26,24,21,0.08)] backdrop-blur-md"
          : "bg-transparent text-on-night",
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:h-20 sm:px-6 lg:px-8">
        <Logo inverted={inverted} />

        <nav className="hidden items-center gap-7 lg:flex" aria-label="Principal">
          {nav.map((item) => {
            const active =
              item.to === "/"
                ? pathname === "/"
                : pathname === item.to || pathname.startsWith(`${item.to}/`);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "relative text-[13px] font-medium uppercase tracking-[0.16em] transition-opacity duration-150 after:absolute after:-bottom-1 after:left-0 after:h-px after:w-full after:origin-left after:scale-x-0 after:bg-current after:transition-transform after:duration-200 hover:opacity-100 hover:after:scale-x-100",
                  active ? "opacity-100 after:scale-x-100" : "opacity-70",
                )}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-1">
          <button
            type="button"
            aria-label="Pesquisar"
            onClick={() => setSearchOpen(true)}
            className="relative flex size-11 items-center justify-center rounded-lg transition-colors duration-150 hover:bg-current/10"
          >
            <Search className="size-5" strokeWidth={1.6} />
          </button>
          <button
            type="button"
            aria-label="Abrir carrinho"
            onClick={() => setCartOpen(true)}
            className="relative flex size-11 items-center justify-center rounded-lg transition-colors duration-150 hover:bg-current/10"
          >
            <ShoppingBag className="size-5" strokeWidth={1.6} />
            {ready && count > 0 ? (
              <span className="absolute right-1.5 top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-sale px-1 text-[10px] font-semibold tabular-nums text-on-sale">
                {count}
              </span>
            ) : null}
          </button>
          <button
            type="button"
            aria-label="Abrir menu"
            onClick={() => setMenuOpen(true)}
            className="relative flex size-11 items-center justify-center rounded-lg transition-colors duration-150 hover:bg-current/10 lg:hidden"
          >
            <Menu className="size-5" strokeWidth={1.6} />
          </button>
        </div>
      </div>
    </header>
  );
}

export { nav };
