import { type ReactNode } from "react";
import { cn } from "@/lib/utils";

export function PageHero({
  kicker,
  title,
  children,
  className,
}: {
  kicker?: string;
  title: string;
  children?: ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("bg-canvas pt-28 pb-10 sm:pt-32 sm:pb-14", className)}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {kicker ? (
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-muted">
            {kicker}
          </p>
        ) : null}
        <h1 className="mt-3 max-w-3xl font-display text-4xl leading-[1.1] tracking-tight sm:text-5xl lg:text-6xl">
          {title}
        </h1>
        {children ? (
          <div className="mt-4 max-w-xl text-base leading-relaxed text-muted">{children}</div>
        ) : null}
      </div>
    </section>
  );
}
