import { useEffect } from "react";
import { Link } from "@tanstack/react-router";
import { Minus, Plus, X } from "lucide-react";
import { toast } from "sonner";
import { getProduct } from "@/lib/catalog";
import { useCart, useStoreUi } from "@/lib/cart-store";
import { Button } from "@/components/ui/button";
import { cn, formatPrice } from "@/lib/utils";

export function CartDrawer() {
  const open = useStoreUi((s) => s.cartOpen);
  const setOpen = useStoreUi((s) => s.setCartOpen);
  const items = useCart((s) => s.items);
  const setQty = useCart((s) => s.setQty);
  const remove = useCart((s) => s.remove);
  const clear = useCart((s) => s.clear);
  const lines = items
    .map((item) => {
      const product = getProduct(item.id);
      return product ? { ...item, product } : null;
    })
    .filter((line): line is NonNullable<typeof line> => Boolean(line));
  const subtotal = lines.reduce((sum, line) => sum + line.product.price * line.qty, 0);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open, setOpen]);

  function checkout() {
    toast("Checkout de demonstração", {
      description:
        "Nenhum pagamento é processado neste modelo. O carrinho existe só no navegador.",
    });
  }

  return (
    <div className={cn("fixed inset-0 z-50", open ? "pointer-events-auto" : "pointer-events-none")}>
      <button
        type="button"
        aria-label="Fechar carrinho"
        onClick={() => setOpen(false)}
        className={cn(
          "absolute inset-0 bg-night/40 transition-opacity duration-300 ease-out",
          open ? "opacity-100" : "opacity-0",
        )}
      />
      <aside
        role="dialog"
        aria-modal="true"
        aria-labelledby="cart-title"
        className={cn(
          "absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-canvas text-ink shadow-lift transition-transform duration-300 ease-out",
          open ? "translate-x-0" : "translate-x-full",
        )}
      >
        <div className="flex items-center justify-between border-b border-line px-5 py-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted">
              Demonstração
            </p>
            <h2 id="cart-title" className="font-display text-2xl">
              Carrinho
            </h2>
          </div>
          <button
            type="button"
            aria-label="Fechar"
            onClick={() => setOpen(false)}
            className="flex size-11 items-center justify-center rounded-lg hover:bg-soft"
          >
            <X className="size-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-5">
          {lines.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <p className="font-display text-2xl">Seu carrinho está vazio</p>
              <p className="mt-2 max-w-xs text-sm text-muted">
                Explore a coleção e adicione peças. Nada é cobrado neste modelo.
              </p>
              <Button className="mt-6" onClick={() => setOpen(false)} variant="night">
                Continuar olhando
              </Button>
            </div>
          ) : (
            <ul className="space-y-5">
              {lines.map((line) => (
                <li key={line.id} className="flex gap-4">
                  <Link
                    to="/produtos/$slug"
                    params={{ slug: line.product.id }}
                    onClick={() => setOpen(false)}
                    className="size-24 shrink-0 overflow-hidden rounded-lg bg-soft"
                  >
                    <img src={line.product.image} alt="" className="size-full object-cover" />
                  </Link>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-3">
                      <Link
                        to="/produtos/$slug"
                        params={{ slug: line.product.id }}
                        onClick={() => setOpen(false)}
                        className="font-display text-lg leading-snug"
                      >
                        {line.product.name}
                      </Link>
                      <button
                        type="button"
                        className="text-xs text-muted underline-offset-2 hover:text-ink hover:underline"
                        onClick={() => remove(line.id)}
                      >
                        Remover
                      </button>
                    </div>
                    <p className="mt-1 text-sm tabular-nums">{formatPrice(line.product.price)}</p>
                    <div className="mt-3 inline-flex items-center rounded-md bg-surface shadow-card">
                      <button
                        type="button"
                        aria-label="Diminuir quantidade"
                        className="flex size-10 items-center justify-center"
                        onClick={() => setQty(line.id, line.qty - 1)}
                      >
                        <Minus className="size-3.5" />
                      </button>
                      <span className="w-6 text-center text-sm tabular-nums">{line.qty}</span>
                      <button
                        type="button"
                        aria-label="Aumentar quantidade"
                        className="flex size-10 items-center justify-center"
                        onClick={() => setQty(line.id, line.qty + 1)}
                      >
                        <Plus className="size-3.5" />
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 ? (
          <div className="border-t border-line px-5 py-5">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted">Subtotal</span>
              <span className="text-lg font-medium tabular-nums">{formatPrice(subtotal)}</span>
            </div>
            <p className="mt-2 text-xs text-muted">
              Frete e impostos não se aplicam — esta loja não processa pedidos reais.
            </p>
            <Button className="mt-4 w-full" size="lg" variant="night" onClick={checkout}>
              Finalizar (demonstração)
            </Button>
            <button
              type="button"
              className="mt-3 w-full text-center text-xs text-muted underline-offset-2 hover:text-ink hover:underline"
              onClick={clear}
            >
              Esvaziar carrinho
            </button>
          </div>
        ) : null}
      </aside>
    </div>
  );
}
