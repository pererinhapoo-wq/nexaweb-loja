import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Search, X } from "lucide-react";
import { searchProducts } from "@/lib/catalog";
import { useStoreUi } from "@/lib/cart-store";
import { cn, formatPrice } from "@/lib/utils";

export function SearchOverlay() {
  const open = useStoreUi((s) => s.searchOpen);
  const setOpen = useStoreUi((s) => s.setSearchOpen);
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const results = useMemo(() => searchProducts(query), [query]);

  useEffect(() => {
    if (!open) return;
    setQuery("");
    const id = window.setTimeout(() => inputRef.current?.focus(), 40);
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      window.clearTimeout(id);
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open, setOpen]);

  return (
    <div className={cn("fixed inset-0 z-50", open ? "pointer-events-auto" : "pointer-events-none")}>
      <button
        type="button"
        aria-label="Fechar pesquisa"
        onClick={() => setOpen(false)}
        className={cn(
          "absolute inset-0 bg-night/45 transition-opacity duration-300 ease-out",
          open ? "opacity-100" : "opacity-0",
        )}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="search-title"
        className={cn(
          "absolute inset-x-0 top-0 mx-auto max-w-2xl bg-canvas px-4 pb-6 pt-5 shadow-lift transition-[opacity,transform] duration-300 ease-out sm:mt-16 sm:rounded-xl sm:px-6",
          open ? "translate-y-0 opacity-100" : "-translate-y-4 opacity-0",
        )}
      >
        <div className="flex items-center justify-between">
          <h2 id="search-title" className="font-display text-2xl">
            Pesquisar
          </h2>
          <button
            type="button"
            aria-label="Fechar"
            onClick={() => setOpen(false)}
            className="flex size-11 items-center justify-center rounded-lg hover:bg-soft"
          >
            <X className="size-5" />
          </button>
        </div>
        <label className="mt-4 flex h-12 items-center gap-3 rounded-lg bg-surface px-4 shadow-[0_0_0_1px_rgba(26,24,21,0.12)]">
          <Search className="size-4 text-muted" />
          <input
            ref={inputRef}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Nome, categoria ou descrição"
            className="h-full w-full bg-transparent text-base text-ink outline-none placeholder:text-muted"
          />
        </label>
        <div className="mt-4 max-h-[55vh] overflow-y-auto">
          {query.trim() && results.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted">
              Nenhum produto encontrado para “{query}”.
            </p>
          ) : (
            <ul>
              {results.map((product) => (
                <li key={product.id}>
                  <Link
                    to="/produtos/$slug"
                    params={{ slug: product.id }}
                    onClick={() => setOpen(false)}
                    className="flex items-center gap-4 rounded-lg px-2 py-3 transition-colors hover:bg-soft"
                  >
                    <img
                      src={product.image}
                      alt=""
                      className="size-16 rounded-md object-cover"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium">{product.name}</p>
                      <p className="text-sm tabular-nums text-muted">
                        {formatPrice(product.price)}
                      </p>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
