import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { type Product } from "@/lib/catalog";
import { useCart, useStoreUi } from "@/lib/cart-store";
import { cn, discountPercent, formatPrice } from "@/lib/utils";

export function ProductCard({
  product,
  className,
}: {
  product: Product;
  className?: string;
}) {
  const add = useCart((s) => s.add);
  const setCartOpen = useStoreUi((s) => s.setCartOpen);
  const discount = product.originalPrice
    ? discountPercent(product.price, product.originalPrice)
    : 0;

  function addToCart() {
    add(product.id);
    toast.success(`${product.name} adicionado ao carrinho`, {
      description: "Demonstração visual — nenhum pedido é enviado.",
      action: {
        label: "Ver carrinho",
        onClick: () => setCartOpen(true),
      },
    });
  }

  return (
    <article className={cn("group flex flex-col", className)}>
      <Link
        to="/produtos/$slug"
        params={{ slug: product.id }}
        className="relative block overflow-hidden rounded-xl bg-soft"
      >
        <div className="aspect-portrait overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="size-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
            style={product.imagePosition ? { objectPosition: product.imagePosition } : undefined}
          />
        </div>
        {product.badge ? (
          <span
            className={cn(
              "absolute left-3 top-3 rounded-full px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.14em]",
              product.badge === "Oferta"
                ? "bg-sale text-on-sale"
                : "bg-primary text-on-primary",
            )}
          >
            {product.badge}
          </span>
        ) : null}
        {discount > 0 ? (
          <span className="absolute right-3 top-3 rounded-full bg-night/80 px-2.5 py-1 text-[11px] font-semibold tabular-nums text-on-night">
            -{discount}%
          </span>
        ) : null}
      </Link>

      <div className="flex flex-1 flex-col pt-4">
        <Link
          to="/produtos/$slug"
          params={{ slug: product.id }}
          className="font-display text-xl leading-snug text-ink transition-opacity duration-150 hover:opacity-70"
        >
          {product.name}
        </Link>
        <div className="mt-2 flex items-baseline gap-2 tabular-nums">
          <span className="text-[15px] font-medium text-ink">{formatPrice(product.price)}</span>
          {product.originalPrice ? (
            <span className="text-sm text-muted line-through">
              {formatPrice(product.originalPrice)}
            </span>
          ) : null}
        </div>
        <button
          type="button"
          onClick={addToCart}
          className="mt-4 h-11 rounded-lg bg-night text-sm font-medium text-on-night transition-[background-color,transform] duration-150 ease-out hover:bg-ink active:scale-[0.96]"
        >
          Adicionar ao carrinho
        </button>
      </div>
    </article>
  );
}
