import { useEffect } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { X } from "lucide-react";
import { nav } from "@/components/layout/header";
import { useStoreUi } from "@/lib/cart-store";
import { cn } from "@/lib/utils";

export function MobileNav() {
  const open = useStoreUi((s) => s.menuOpen);
  const setOpen = useStoreUi((s) => s.setMenuOpen);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    setOpen(false);
  }, [pathname, setOpen]);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open, setOpen]);

  return (
    <div className={cn("fixed inset-0 z-50 lg:hidden", open ? "pointer-events-auto" : "pointer-events-none")}>
      <button
        type="button"
        aria-label="Fechar menu"
        onClick={() => setOpen(false)}
        className={cn(
          "absolute inset-0 bg-night/40 transition-opacity duration-300",
          open ? "opacity-100" : "opacity-0",
        )}
      />
      <aside
        className={cn(
          "absolute left-0 top-0 flex h-full w-80 max-w-full flex-col bg-canvas px-6 py-5 shadow-lift transition-transform duration-300 ease-out",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center justify-between">
          <p className="font-display text-2xl">Menu</p>
          <button
            type="button"
            aria-label="Fechar"
            onClick={() => setOpen(false)}
            className="flex size-11 items-center justify-center rounded-lg hover:bg-soft"
          >
            <X className="size-5" />
          </button>
        </div>
        <nav className="mt-8 flex flex-col gap-1">
          {nav.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="rounded-lg px-3 py-3 text-lg font-medium hover:bg-soft"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>
    </div>
  );
}
