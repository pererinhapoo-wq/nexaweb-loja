export type CategoryId =
  | "moda"
  | "tecnologia"
  | "casa"
  | "acessorios"
  | "beleza"
  | "esportes";

export type ProductBadge = "Novo" | "Oferta";

export type Product = {
  id: string;
  name: string;
  category: CategoryId;
  price: number;
  originalPrice?: number;
  badge?: ProductBadge;
  image: string;
  imagePosition?: string;
  description: string;
  details: string;
  benefits: string[];
  featured?: boolean;
};

export type Category = {
  id: CategoryId;
  name: string;
  image: string;
  blurb: string;
};

export const categories: Category[] = [
  {
    id: "moda",
    name: "Moda",
    image: "/images/cat-moda.jpg",
    blurb: "Peças atemporais, corte preciso e tecidos escolhidos à mão.",
  },
  {
    id: "tecnologia",
    name: "Tecnologia",
    image: "/images/cat-tecnologia.jpg",
    blurb: "Objetos discretos que acompanham o dia com silêncio e precisão.",
  },
  {
    id: "casa",
    name: "Casa",
    image: "/images/cat-casa.jpg",
    blurb: "Formas esculturais para ambientes que pedem calma.",
  },
  {
    id: "acessorios",
    name: "Acessórios",
    image: "/images/cat-acessorios.jpg",
    blurb: "Detalhes que completam o vestir — e duram anos.",
  },
  {
    id: "beleza",
    name: "Beleza",
    image: "/images/cat-beleza.jpg",
    blurb: "Fórmulas simples, frascos honestos, ritual sem pressa.",
  },
  {
    id: "esportes",
    name: "Esportes",
    image: "/images/cat-esportes.jpg",
    blurb: "Movimento com materiais nobres e silhueta limpa.",
  },
];

export const products: Product[] = [
  {
    id: "casaco-lumen",
    name: "Casaco Lumen Alpino",
    category: "moda",
    price: 890,
    originalPrice: 1180,
    badge: "Oferta",
    image: "/images/prod-casaco.jpg",
    description:
      "Lã mista de toque seco, ombro caído e forro de viscose. Um casaco de inverno pensado para o dia inteiro — da rua ao escritório.",
    details:
      "Corpo estruturado sem rigidez, bolsos internos e um cinto removível. Tingimento em tom camel, exclusivo desta coleção demonstrativa.",
    benefits: [
      "Lã mista de alta densidade",
      "Forro respirável",
      "Corte unissex",
      "Feito para durar estações",
    ],
  },
  {
    id: "sobretudo-campo",
    name: "Sobretudo Campo",
    category: "moda",
    price: 1120,
    badge: "Novo",
    image: "/images/prod-sobretudo.jpg",
    description:
      "Sobretudo longo em lã camel, gola clássica e caimento vertical. A peça âncora do guarda-roupa de meia-estação.",
    details:
      "Comprimento midi, botões de osso reconstituído e interior com presilha para ombro. Silhueta reta, sem excesso de volume.",
    benefits: [
      "Lã prensada",
      "Gola inteira",
      "Dois bolsos profundos",
      "Caimento alongado",
    ],
  },
  {
    id: "fone-aura",
    name: "Fone Aura Pro",
    category: "tecnologia",
    price: 649,
    badge: "Novo",
    image: "/images/prod-fone.jpg",
    description:
      "Over-ear em couro creme e copas de nogueira. Cancelamento discreto, 32 horas de bateria e um visual que não parece gadget.",
    details:
      "Drivers de 40 mm, Bluetooth 5.3 e estojo de tecido. Pensado para quem escuta o dia inteiro sem querer um objeto técnico sobre a mesa.",
    benefits: [
      "Até 32h de bateria",
      "Copas em nogueira",
      "Espuma de memória",
      "Carregamento USB-C",
    ],
  },
  {
    id: "luminaria-orbit",
    name: "Luminária Orbit",
    category: "casa",
    price: 420,
    image: "/images/prod-luminaria.jpg",
    description:
      "Globo de cerâmica esmaltada em aveia, cúpula de linho e haste de nogueira. Luz quente, 2700K, para mesas e cantos de leitura.",
    details:
      "Base estável, interruptor no cabo e lâmpada LED inclusa nesta demonstração visual. Dimensões pensadas para consoles estreitos.",
    benefits: [
      "Cerâmica artesanal",
      "Luz 2700K",
      "Cúpula de linho",
      "Cabo têxtil",
    ],
  },
  {
    id: "relogio-nimbus",
    name: "Relógio Nimbus 42",
    category: "acessorios",
    price: 1290,
    originalPrice: 1590,
    badge: "Oferta",
    image: "/images/prod-relogio.jpg",
    description:
      "Caixa redonda 42 mm, mostrador areia e pulseira de couro conhaque. Um relógio de pulso que não compete com o restante do vestir.",
    details:
      "Movimento de quartzo de alta precisão, vidro mineral e fecho de fivela. Resistência à água 50 m — uso urbano, não mergulho.",
    benefits: [
      "Mostrador areia",
      "Pulseira em couro",
      "42 mm",
      "Vidro mineral",
    ],
  },
  {
    id: "serum-lumina",
    name: "Sérum Lúmina Noite",
    category: "beleza",
    price: 189,
    image: "/images/prod-serum.jpg",
    description:
      "Sérum noturno em vidro âmbar. Textura fluida, absorção rápida e uma fragrância quase inexistente — só um fundo mineral.",
    details:
      "30 ml. Rotina sugerida: duas gotas no rosto limpo, à noite. Fórmula demonstrativa, sem alegações clínicas.",
    benefits: [
      "Frasco âmbar 30 ml",
      "Textura fluida",
      "Sem perfume marcante",
      "Pipeta de vidro",
    ],
  },
  {
    id: "tenis-veloce",
    name: "Tênis Veloce Run",
    category: "esportes",
    price: 579,
    originalPrice: 720,
    badge: "Oferta",
    image: "/images/prod-tenis.jpg",
    description:
      "Camurça aveia, sola de borracha natural e palmilha removível. Um tênis de corrida urbana com visual de ateliê, não de pista.",
    details:
      "Drop 6 mm, entressola reativa e cabedal que respira. Numeração unissex. Indicado para treinos leves e o caminho até o trabalho.",
    benefits: [
      "Camurça integral",
      "Sola de borracha",
      "Drop 6 mm",
      "Palmilha removível",
    ],
  },
  {
    id: "poltrona-solstice",
    name: "Poltrona Solstice",
    category: "casa",
    price: 2490,
    badge: "Novo",
    image: "/images/prod-poltrona.jpg",
    imagePosition: "center",
    featured: true,
    description:
      "Peça âncora da casa. Estrutura de madeira maciça, revestimento em bouclé aveia e um encosto baixo que convida a ficar.",
    details:
      "Desenhada para salas claras e cantos de leitura. Pés recuados, assento profundo e uma manta de linho sugerida à parte. Edição limitada desta coleção demonstrativa.",
    benefits: [
      "Bouclé de lã",
      "Estrutura maciça",
      "Assento profundo",
      "Feita sob encomenda visual",
    ],
  },
];

export const reviews = [
  {
    id: "r1",
    name: "Marina Velloso",
    city: "Curitiba",
    quote:
      "O casaco chegou com um caimento que eu não esperava de uma compra online. A loja parece ter escolhido cada peça com paciência.",
    product: "Casaco Lumen Alpino",
  },
  {
    id: "r2",
    name: "Rafael Quintanilha",
    city: "Belo Horizonte",
    quote:
      "O fone não parece um acessório técnico. Fica sobre a mesa como um objeto de casa — e o som acompanha o dia inteiro.",
    product: "Fone Aura Pro",
  },
  {
    id: "r3",
    name: "Helena Moraes",
    city: "Salvador",
    quote:
      "A poltrona mudou o canto da sala. É a primeira peça que as visitas tocam. Vale cada centavo desta coleção.",
    product: "Poltrona Solstice",
  },
] as const;

export const contact = {
  email: "contato@nexastore.demo",
  phone: "+55 (11) 3456-0090",
  hours: "Segunda a sexta, 9h às 18h",
  address: "Alameda das Acácias, 480 — Vila Editorial, São Paulo, SP",
};

export function getProduct(id: string) {
  return products.find((product) => product.id === id);
}

export function getCategory(id: string) {
  return categories.find((category) => category.id === id);
}

export function productsByCategory(id: CategoryId) {
  return products.filter((product) => product.category === id);
}

export function offerProducts() {
  return products.filter((product) => product.originalPrice);
}

export function featuredProducts() {
  return products.slice(0, 8);
}

export function searchProducts(query: string) {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  return products.filter((product) => {
    const category = getCategory(product.category)?.name ?? "";
    return (
      product.name.toLowerCase().includes(q) ||
      product.description.toLowerCase().includes(q) ||
      category.toLowerCase().includes(q)
    );
  });
}

export function relatedProducts(id: string, limit = 4) {
  const current = getProduct(id);
  if (!current) return products.slice(0, limit);
  return products
    .filter((product) => product.id !== id)
    .sort((a, b) => {
      const aSame = a.category === current.category ? 0 : 1;
      const bSame = b.category === current.category ? 0 : 1;
      return aSame - bSame;
    })
    .slice(0, limit);
}
