import { create } from "zustand";
import { persist } from "zustand/middleware";
import { getProduct, type Product } from "@/lib/catalog";

export type CartItem = {
  id: string;
  qty: number;
};

type CartState = {
  items: CartItem[];
  add: (id: string, qty?: number) => void;
  remove: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  clear: () => void;
  count: () => number;
  lines: () => Array<CartItem & { product: Product }>;
  subtotal: () => number;
};

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      add: (id, qty = 1) => {
        const items = [...get().items];
        const existing = items.find((item) => item.id === id);
        if (existing) existing.qty += qty;
        else items.push({ id, qty });
        set({ items });
      },
      remove: (id) => set({ items: get().items.filter((item) => item.id !== id) }),
      setQty: (id, qty) => {
        if (qty <= 0) {
          set({ items: get().items.filter((item) => item.id !== id) });
          return;
        }
        set({
          items: get().items.map((item) => (item.id === id ? { ...item, qty } : item)),
        });
      },
      clear: () => set({ items: [] }),
      count: () => get().items.reduce((sum, item) => sum + item.qty, 0),
      lines: () =>
        get()
          .items.map((item) => {
            const product = getProduct(item.id);
            return product ? { ...item, product } : null;
          })
          .filter((line): line is CartItem & { product: Product } => Boolean(line)),
      subtotal: () =>
        get()
          .lines()
          .reduce((sum, line) => sum + line.product.price * line.qty, 0),
    }),
    { name: "nexa-store-cart-demo", partialize: (state) => ({ items: state.items }) },
  ),
);

type UiState = {
  cartOpen: boolean;
  searchOpen: boolean;
  menuOpen: boolean;
  setCartOpen: (open: boolean) => void;
  setSearchOpen: (open: boolean) => void;
  setMenuOpen: (open: boolean) => void;
};

export const useStoreUi = create<UiState>((set) => ({
  cartOpen: false,
  searchOpen: false,
  menuOpen: false,
  setCartOpen: (cartOpen) => set({ cartOpen, menuOpen: false, searchOpen: false }),
  setSearchOpen: (searchOpen) => set({ searchOpen, menuOpen: false, cartOpen: false }),
  setMenuOpen: (menuOpen) => set({ menuOpen, searchOpen: false, cartOpen: false }),
}));
